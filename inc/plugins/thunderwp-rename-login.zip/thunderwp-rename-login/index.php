<?php
// Silence is Golden.
