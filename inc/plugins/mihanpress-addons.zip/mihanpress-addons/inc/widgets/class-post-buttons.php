<?php
namespace MihanPress\MihanPress_Addons;

/**
 * Adds Post_Buttons widget.
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */
class Post_Buttons extends \WP_Widget {

	/**
	 * Register widget with WordPress.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mihanpress_post_buttons',
			esc_html__( 'ابزارک دکمه های نوشته', 'mihanpress-addons' ),
			array( 'description' => esc_html__( 'ابزارک نمایش دکمه های نوشته - قالب میهن پرس', 'mihanpress-addons' ) )
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 * @since 1.0.0
	 */
	public function widget( $args, $instance ) {
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		?>
		<div class="mp-widget__post-buttons">
		<?php
		$items = get_post_meta( get_the_ID(), 'mihanpress_post_extra_buttons_items', true );
		if ( ! empty( $items[0]['text'] ) ) :
			foreach ( $items as $item ) :
				if ( ! empty( $item['text'] ) ) :
					?>
					<a href="<?php echo ! empty( $item['link'] ) ? esc_url( $item['link'] ) : ''; ?>" 
						target="_<?php echo esc_attr( $item['target'] ); ?>"
						<?php echo 'download' === $item['type'] ? 'download' : ''; ?>
						class="btn <?php echo esc_attr( $item['color'] ); ?>">

						<?php echo esc_html( $item['text'] ); ?>
					</a>
					<?php
				endif;
			endforeach;
		endif;
		?>
		</div>
		<?php
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 * @since 1.0.0
	 */
	public function form( $instance ) {
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'نام', 'mihanpress-addons' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : ''; ?>">
		</p>

		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 * @since 1.0.0
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title'] = ! empty( $new_instance['title'] ) ? $new_instance['title'] : '';

		return $instance;
	}
}
