<?php
namespace MihanPress\MihanPress_Addons;

/**
 * Adds Posts widget.
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */
class Posts extends \WP_Widget {

	/**
	 * Register widget with WordPress.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mihanpress_posts',
			esc_html_x( 'نوشته ها', 'ابزارک نوشته ها', 'mihanpress-addons' ),
			array( 'description' => esc_html__( 'ابزارک نوشته ها - قالب میهن پرس', 'mihanpress-addons' ) )
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 * @since 1.0.0
	 */
	public function widget( $args, $instance ) {
		if ( 'slider' === $instance['style'] ) {
			wp_enqueue_style( 'mihanpress-flickity-carousel' );
			wp_enqueue_script( 'mihanpress-flickity-carousel-js' );
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		$the_args = array(
			'post_type'      => $instance['post_type'],
			'posts_per_page' => $instance['posts_per_page'],
			'post__not_in'   => $instance['post__not_in'],
			'order'          => $instance['order'],
		);
		if ( ! empty( $instance['terms_tax'] ) ) {
			$the_args['tax_query'] = array(
				array(
					'taxonomy' => $instance['taxonomy'],
					'field'    => 'term_id',
					'terms'    => $instance['terms_tax'],
				),
			);
		}
		$query = new \WP_Query( $the_args );

		if ( $query->have_posts() ) {
			if ( 'slider' === $instance['style'] ) {
				?>
				<section class="carousel" data-flickity='{ "autoPlay":true,"wrapAround":false,"contain": true, "pageDots": false , "prevNextButtons":false }'>
				<?php
			}
			while ( $query->have_posts() ) {
				$query->the_post();
				if ( empty( $instance['style'] ) ) {
					?>

						<div class="mini-card-row mp-widget__post">
							<figure class="card__thumbnail">
								<?php the_post_thumbnail(); ?>
							</figure>
							<div class="card__content">
								<a href="<?php the_permalink(); ?>">
									<h1 class="card__title"><?php the_title(); ?></h1>
								</a>
								<span><?php echo get_the_date( 'd  M  Y' ); ?></span>
							</div>
						</div>
					<?php
				} elseif ( 'slider' === $instance['style'] ) {
					?>
						<figure class="mp-widget__slider carousel-cell">
							<?php the_post_thumbnail(); ?>
							<figcaption>
								<a href="<?php the_permalink(); ?>">
									<h1 class="h3 card-title"><?php the_title(); ?></h1>
								</a>
								<span><?php echo get_the_date( 'd  M  Y' ); ?></span>
								<footer>
									<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
										<div class="archive-author">
										<?php echo get_avatar( get_the_author_meta( 'user_email' ), '35' ); ?>
											<span class="mr-2">
												<?php echo esc_html( get_the_author_meta( 'display_name' ) ); ?>
											</span>
										</div>
									</a>
								</footer>
							</figcaption>
						</figure>
					<?php

				}
			}
			if ( 'slider' === $instance['style'] ) {
				?>
				</section>
				<?php
			}
		}
		wp_reset_postdata();

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 * @since 1.0.0
	 */
	public function form( $instance ) {
		$title          = isset( $instance['title'] ) ? $instance['title'] : '';
		$post_types     = get_post_types( array( 'public' => true ), 'object' );
		$post_type      = isset( $instance['post_type'] ) ? $instance['post_type'] : 'post';
		$posts_per_page = ( empty( $instance['posts_per_page'] ) ) ? 5 : $instance['posts_per_page'];
		$post__not_in   = '';
		if ( ! empty( $instance['post__not_in'] ) ) {
			foreach ( $instance['post__not_in'] as $val ) {
				$post__not_in .= $val . ',';
			}
			$post__not_in = substr_replace( $post__not_in, '', -1 );
		}
		$taxonomy  = isset( $instance['taxonomy'] ) ? $instance['taxonomy'] : 'category';
		$terms_tax = isset( $instance['terms_tax'] ) ? $instance['terms_tax'] : '';
		$order     = isset( $instance['order'] ) ? $instance['order'] : 'ASC';

		?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'نام', 'mihanpress-addons' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post_type' ) ); ?>"><?php esc_html_e( 'پست تایپ :', 'mihanpress-addons' ); ?></label>

				<select name="<?php echo esc_attr( $this->get_field_name( 'post_type' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'post_type' ) ); ?>" class="mihanpress_post_type">
					<option value="" <?php echo empty( $post_type ) ? 'selected' : ''; ?>>
						<?php esc_html_e( '_گزینش_', 'mihanpress-addons' ); ?>
					</option>
					<?php foreach ( $post_types as $val ) { ?>
						<option value="<?php echo esc_attr( $val->name ); ?>" <?php echo $val->name === $post_type ? 'selected' : ''; ?>>
							<?php echo esc_html( $val->label ); ?>
						</option>
					<?php } ?>
				</select>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'posts_per_page' ) ); ?>"><?php esc_html_e( 'تعداد نمایش :', 'mihanpress-addons' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'posts_per_page' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_per_page' ) ); ?>" type="number" value="<?php echo esc_attr( $posts_per_page ); ?>">
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'post__not_in' ) ); ?>"><?php esc_html_e( 'این پست ها را نمایش نده', 'mihanpress-addons' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'post__not_in' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'post__not_in' ) ); ?>" type="text" value="<?php echo esc_attr( $post__not_in ); ?>">
			</p>

			<p>
				<?php esc_html_e( ' مثال : 1,24,56', 'mihanpress-addons' ); ?>
			</p>


			<?php
				$object_tax   = get_object_taxonomies( $post_type, 'names' );
				$object_tax_0 = isset( $object_tax[0] ) ? $object_tax[0] : '';
				echo '<input type="hidden" value="' . esc_attr( $object_tax_0 ) . '" name="' . esc_attr( $this->get_field_name( 'taxonomy' ) ) . '">';
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'terms_tax' ) ); ?>"><?php esc_html_e( 'دسته ها', 'mihanpress-addons' ); ?></label>
			<?php
			if ( $object_tax ) {
				$terms = get_terms(
					array(
						'taxonomy'   => $object_tax[0],
						'hide_empty' => false,
					)
				);
				$count = ! empty( $terms_tax ) ? count( $terms_tax ) : 0;
				echo '<div class="terms_tax">';
				foreach ( $terms as $term ) {
					?>
						<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'terms_tax' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'terms_tax' ) ); ?>[]" type="checkbox" value="<?php echo intval( $term->term_id ); ?>" 
															<?php
															for ( $i = 0; $count > $i;$i++ ) {
																if ( $terms_tax[ $i ] === $term->term_id ) {
																	echo 'checked';
																}
															}
															?>
						><?php echo esc_html( $term->name ); ?>
					<?php
				}
				echo '</div>';
			}
			?>

			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>"><?php esc_html_e( 'ترتیب نمایش :', 'mihanpress-addons' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>" type="radio" value="ASC" <?php echo empty( $order ) ? 'checked' : ''; ?> <?php echo 'ASC' === $order ? 'checked' : ''; ?>> <?php esc_html_e( 'صعودی', 'mihanpress-addons' ); ?>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>" type="radio" value="DESC" <?php echo 'DESC' === $order ? 'checked' : ''; ?>> <?php esc_html_e( 'نزولی', 'mihanpress-addons' ); ?>
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'سبک :', 'mihanpress-addons' ); ?></label>

				<select name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>">
					<option value="" <?php echo empty( $instance['style'] ) ? 'selected' : ''; ?>><?php esc_html_e( 'پیشفرض', 'mihanpress-addons' ); ?></option>
					<option value="slider" <?php echo ( isset( $instance['style'] ) && 'slider' === $instance['style'] ) ? 'selected' : ''; ?>><?php esc_html_e( 'اسلایدر', 'mihanpress-addons' ); ?></option>
				</select>

			</p>


			<script>
				jQuery(document).ready(function($) {
					$('.mihanpress_post_type').on('change', function() {
						var option = $(this).find('option:selected').val();
						$.ajax({
							type: 'POST',
							url: '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
							data: {
								action: 'mihanpress_ajax_widget_posts',
								post_type: option
							},
							beforeSend: function() {
								$('.terms_tax').html('');
							},
							success: function(respond) {
								$('.terms_tax').html(respond);
							}
						})
					})
				})
			</script>
			<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 * @since 1.0.0
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title']          = ! empty( $new_instance['title'] ) ? $new_instance['title'] : '';
		$instance['post_type']      = ! empty( $new_instance['post_type'] ) ? $new_instance['post_type'] : '';
		$instance['posts_per_page'] = ! empty( $new_instance['posts_per_page'] ) ? $new_instance['posts_per_page'] : '';
		$instance['post__not_in']   = ! empty( $new_instance['post__not_in'] ) ? array_map( 'intval', explode( ',', $new_instance['post__not_in'] ) ) : '';
		$instance['taxonomy']       = ! empty( $new_instance['taxonomy'] ) ? $new_instance['taxonomy'] : '';
		$instance['terms_tax']      = ! empty( $new_instance['terms_tax'] ) ? array_map( 'intval', $new_instance['terms_tax'] ) : '';
		$instance['order']          = ! empty( $new_instance['order'] ) ? $new_instance['order'] : '';
		$instance['style']          = ! empty( $new_instance['style'] ) ? $new_instance['style'] : '';

		return $instance;
	}
}

add_action( 'wp_ajax_mihanpress_ajax_widget_posts', 'mihanpress_ajax_widget_posts' );
function mihanpress_ajax_widget_posts() {

	$post_type  = sanitize_text_field( $_POST['post_type'] );
	$object_tax = get_object_taxonomies( $post_type, 'names' );
	if ( $object_tax ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $object_tax[0],
				'hide_empty' => false,
			)
		);
		foreach ( $terms as $term ) {
			?>
				<input class="widefat" id="widget-mihanpress_posts-2-terms_tax" name="widget-mihanpress_posts[2][terms_tax][]" type="checkbox" value="<?php echo intval( $term->term_id ); ?>" 
									<?php
									for ( $i = 0; $count > $i;$i++ ) {
										if ( $terms_tax[ $i ] === $term->term_id ) {
											echo 'checked';
										}
									}
									?>
				><?php echo esc_html( $term->name ); ?>
			<?php
		}
	}
	wp_die();
}
