<?php
namespace MihanPress\MihanPress_Addons;

/**
 * Adds Post_Navigation widget.
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */
class Post_Navigation extends \WP_Widget {

	/**
	 * Register widget with WordPress.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mihanpress_post_navigation',
			esc_html__( 'ابزارک پست بعدی و قبلی', 'mihanpress-addons' ),
			array( 'description' => esc_html__( 'ابزارک نمایش دکمه پست قبلی و پست بعدی - قالب میهن پرس', 'mihanpress-addons' ) )
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 * @since 1.0.0
	 */
	public function widget( $args, $instance ) {
		if ( is_single() ) {
			$next_post = get_next_post();
			$prev_post = get_previous_post();

			if ( $next_post || $prev_post ) {
				$pagination_classes = '';
				if ( ! $next_post ) {
					$pagination_classes = ' only-one only-prev';
				} elseif ( ! $prev_post ) {
					$pagination_classes = ' only-one only-next';
				}
				echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

				echo '<nav class="mp-widget__post_navigation ' . $pagination_classes . '" role="navigation">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				if ( 'on' === $instance['before_btn'] && $prev_post ) {
					echo '<a href="' . esc_url( get_permalink( $prev_post->ID ) ) . '" class="btn btn-secondary ' . esc_attr( $instance['before_class'] ) . '">' . esc_html__( 'پست قبلی', 'mihanpress-addons' ) . '</a>';
				}
				if ( 'on' === $instance['after_btn'] && $next_post ) {
					echo '<a href="' . esc_url( get_permalink( $next_post->ID ) ) . '" class="btn btn-warning ' . esc_attr( $instance['after_class'] ) . '">' . esc_html__( 'پست بعدی', 'mihanpress-addons' ) . '</a>';
				}
				echo '</nav>';
				echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 * @since 1.0.0
	 */
	public function form( $instance ) {
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'before_btn' ) ); ?>"><?php esc_html_e( 'نمایش دکمه قبلی', 'mihanpress-addons' ); ?></label>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'before_btn' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'before_btn' ) ); ?>" <?php echo ! empty( $instance['before_btn'] ) ? 'checked' : ''; ?>>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'after_btn' ) ); ?>"><?php esc_html_e( 'نمایش دکمه بعدی', 'mihanpress-addons' ); ?></label>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'after_btn' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'after_btn' ) ); ?>" <?php echo ! empty( $instance['after_btn'] ) ? 'checked' : ''; ?>>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'before_class' ) ); ?>"><?php esc_html_e( 'کلاس های CSS دکمه قبلی', 'mihanpress-addons' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'before_class' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'before_class' ) ); ?>" type="text" value="<?php echo isset( $instance['before_class'] ) ? esc_attr( $instance['before_class'] ) : ''; ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'after_class' ) ); ?>"><?php esc_html_e( 'کلاس های CSS دکمه بعدی', 'mihanpress-addons' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'after_class' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'after_class' ) ); ?>" type="text" value="<?php echo isset( $instance['after_class'] ) ? esc_attr( $instance['after_class'] ) : ''; ?>">
		</p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 * @since 1.0.0
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['before_btn']   = ! empty( $new_instance['before_btn'] ) ? $new_instance['before_btn'] : '';
		$instance['after_btn']    = ! empty( $new_instance['after_btn'] ) ? $new_instance['after_btn'] : '';
		$instance['before_class'] = ! empty( $new_instance['before_class'] ) ? $new_instance['before_class'] : '';
		$instance['after_class']  = ! empty( $new_instance['after_class'] ) ? $new_instance['after_class'] : '';
		return $instance;
	}
}
