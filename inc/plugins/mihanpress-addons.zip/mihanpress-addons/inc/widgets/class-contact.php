<?php
namespace MihanPress\MihanPress_Addons;

/**
 * Adds Contact widget.
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */
class Contact extends \WP_Widget {

	/**
	 * Register widget with WordPress.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mihanpress_contact',
			esc_html__( 'ابزارک تماس با ما', 'mihanpress-addons' ),
			array( 'description' => esc_html__( 'ابزارک تماس با ما - قالب میهن پرس', 'mihanpress-addons' ) )
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 * @since 1.0.0
	 */
	public function widget( $args, $instance ) {
		global $mihanpress_options;
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		?>

		<div class="contact-section pr-3 pl-3">
			<?php if ( 'on' === $instance['number'] ) : ?>
				<div class="mb-3">
					<span class="flaticon-phone-call"></span>
					<span class="number">
						<a href="tel:<?php echo esc_attr( $mihanpress_options['contact_number'] ); ?>">
							<?php echo esc_html( $mihanpress_options['contact_number'] ); ?>
						</a>

					</span>
				</div>
			<?php endif; ?>
			<?php if ( 'on' === $instance['email'] ) : ?>
				<div class="mb-3">
					<span class="flaticon-email"></span>
					<span class="d-inline-block">
						<?php echo esc_html( $mihanpress_options['contact_email'] ); ?>
					</span>
				</div>
			<?php endif; ?>
			<?php if ( 'on' === $instance['address'] ) : ?>
				<div class="mb-3">
					<span class="flaticon-pin-1 mb-0"></span>
					<span class="mb-0">
						<?php echo wp_kses_post( $mihanpress_options['contact_address'] ); ?>
					</span>
				</div>
			<?php endif; ?>

			<?php
			if ( 'on' === $instance['social'] ) :
				?>
				<div class="social-media-s d-flex justify-content-center flex-wrap">
					<?php
					$icons = \MihanPress_Addons::get_social_icons();
					foreach ( $icons as $item ) {
						if ( ! empty( $item ) ) {
							echo '<a href="' . esc_url( $item['link'] ) . '"><span class="' . esc_attr( $item['icon'] ) . '"></span></a>';
						}
					}
					?>
				</div>
				<?php
			endif;
			?>
		</div>
		<?php

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 * @since 1.0.0
	 */
	public function form( $instance ) {
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'نام', 'mihanpress-addons' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : ''; ?>">
		</p>


		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'شماره تلفن', 'mihanpress-addons' ); ?></label>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" <?php echo ! empty( $instance['number'] ) ? 'checked' : ''; ?>>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_html_e( 'ایمیل :', 'mihanpress-addons' ); ?></label>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" <?php echo ! empty( $instance['email'] ) ? 'checked' : ''; ?>>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'address' ) ); ?>"><?php esc_html_e( 'آدرس', 'mihanpress-addons' ); ?></label>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'address' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'address' ) ); ?>" <?php echo ! empty( $instance['address'] ) ? 'checked' : ''; ?>>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'social' ) ); ?>"><?php esc_html_e( 'شبکه های اجتماعی', 'mihanpress-addons' ); ?></label>
			<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'social' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'social' ) ); ?>" <?php echo ! empty( $instance['social'] ) ? 'checked' : ''; ?>>
		</p>

		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 * @since 1.0.0
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title']   = ! empty( $new_instance['title'] ) ? $new_instance['title'] : '';
		$instance['number']  = ! empty( $new_instance['number'] ) ? $new_instance['number'] : '';
		$instance['email']   = ! empty( $new_instance['email'] ) ? $new_instance['email'] : '';
		$instance['address'] = ! empty( $new_instance['address'] ) ? $new_instance['address'] : '';
		$instance['social']  = ! empty( $new_instance['social'] ) ? $new_instance['social'] : '';
		return $instance;
	}
}
