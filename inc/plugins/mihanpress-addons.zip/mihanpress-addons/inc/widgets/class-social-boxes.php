<?php
namespace MihanPress\MihanPress_Addons;

/**
 * Adds Social_Boxes widget.
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */
class Social_Boxes extends \WP_Widget {

	/**
	 * Register widget with WordPress.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mihanpress_social_boxes',
			esc_html__( 'ابزارک شبکه های اجتماعی', 'mihanpress-addons' ),
			array( 'description' => esc_html__( 'ابزارک باکس شبکه های اجتماعی فوتر - قالب میهن پرس', 'mihanpress-addons' ) )
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 * @since 1.0.0
	 */
	public function widget( $args, $instance ) {
		global $mihanpress_addons;
		$icons = $mihanpress_addons::get_social_icons();

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<div class="d-flex flex-wrap justify-content-between social-boxes-container">';
		foreach ( $icons as $item ) {
			if ( ! empty( $item ) ) {
				$slug = $item['slug'];
				if ( 'on' === $instance[ $slug ] ) {
					?>
					<div class="col-lg-6 col-md-6 p-1">
						<a href="<?php echo esc_url( $item['link'] ); ?>" target="_blank" class="social-box text-center d-flex justify-content-center flex-column mb-2 <?php echo 'social-box-' . esc_attr( $item['slug'] ); ?>">
							<span class="<?php echo esc_attr( $item['icon'] ); ?>"></span>
							<span><?php echo esc_html( $item['title'] ); ?></span>
						</a>
					</div>
					<?php
				}
			}
		}

		echo '</div>';
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 * @since 1.0.0
	 */
	public function form( $instance ) {
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'نام', 'mihanpress-addons' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : ''; ?>">
		</p>

		<?php
		global $mihanpress_addons;
		$icons = $mihanpress_addons::get_social_icons();
		foreach ( $icons as $item ) {
			if ( ! empty( $item ) ) {
				$slug = $item['slug'];
				?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( $slug ) ); ?>"><?php echo esc_html( $item['title'] ); ?></label>
					<input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( $slug ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $slug ) ); ?>" <?php echo ! empty( $instance[ $slug ] ) ? 'checked' : ''; ?>>
				</p>
				<?php
			}
		}
		?>

		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 * @since 1.0.0
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		global $mihanpress_addons;
		$icons = $mihanpress_addons::get_social_icons();
		foreach ( $icons as $item ) {
			$slug              = $item['slug'];
			$instance[ $slug ] = ( ! empty( $new_instance[ $slug ] ) ) ? $new_instance[ $slug ] : '';
		}
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? $new_instance['title'] : '';
		return $instance;
	}
}
