<?php
/*
Plugin Name: افزودنی های میهن پرس
Plugin URI: https://www.zhaket.com/web/mihanwp-wordpress-theme/
Description: این افزونه همراه با قالب میهن پرس ارائه شده است و شامل برخی امکانات مهم مانند ابزارک های اختصاصی و پنل تنظیمات و ... میباشد.
Version: 1.6.0
Author: Thunder WP
Author URI: https://www.zhaket.com/store/web/thunder-wp/
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: mihanpress-addons
Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MihanPress_Addons {

	/**
	 * MihanPress_Addons The single instance of the MihanPress_Addons.
	 *
	 * @since 1.0.0
	 */
	public static $instance;

	/**
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 */
	public function instance() {
		if ( ! isset( self::$instance ) ) {
			$object         = new MihanPress_Addons();
			self::$instance = $object->init();
		}
		return self::$instance;
	}

	/**
	 * Load widgets files
	 *
	 * @since 1.0.0
	 */
	private function include_plugin_files() {
		/** Load redux core */
		if ( ! class_exists( 'Redux' ) ) {
			require_once plugin_dir_path( __FILE__ ) . 'theme-options/framework/framework.php';
		}

		/** Load redux config */
		require_once plugin_dir_path( __FILE__ ) . 'theme-options/config.php';

		require_once plugin_dir_path( __FILE__ ) . 'meta-boxes/meta-boxes-functions.php';
		require_once plugin_dir_path( __FILE__ ) . 'inc/post-like.php';

		/** Include Widgets files */
		include_once plugin_dir_path( __FILE__ ) . 'inc/widgets/class-posts.php';
		include_once plugin_dir_path( __FILE__ ) . 'inc/widgets/class-contact.php';
		include_once plugin_dir_path( __FILE__ ) . 'inc/widgets/class-social-boxes.php';
		include_once plugin_dir_path( __FILE__ ) . 'inc/widgets/class-post-navigation.php';
		include_once plugin_dir_path( __FILE__ ) . 'inc/widgets/class-post-buttons.php';
	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 */
	public function i18n() {
		load_plugin_textdomain( 'mihanpress-addons' );
	}


	/**
	 * Register Custom WP widgets
	 *
	 * @since 1.0.0
	 */
	public function register_widgets() {
		register_widget( 'MihanPress\MihanPress_Addons\Posts' );
		register_widget( 'MihanPress\MihanPress_Addons\Contact' );
		register_widget( 'MihanPress\MihanPress_Addons\Social_Boxes' );
		register_widget( 'MihanPress\MihanPress_Addons\Post_Navigation' );
		register_widget( 'MihanPress\MihanPress_Addons\Post_Buttons' );
	}


	/**
	 * Get an array of social media icons
	 *
	 * @since 1.0.0
	 */
	public static function get_social_icons() {
		global $mihanpress_options;
		$social_media_icons = array(
			'1' === $mihanpress_options['contact_media_whatsapp'] ? array(
				'slug'  => 'whatsapp',
				'link'  => $mihanpress_options['contact_media_whatsapp_link'],
				'icon'  => 'flaticon-phone-call',
				'title' => esc_html__( 'آدرس واتساپ', 'mihanpress-addons' ),
			) : '',
			'1' === $mihanpress_options['contact_media_facebook'] ? array(
				'slug'  => 'facebook',
				'link'  => $mihanpress_options['contact_media_facebook_link'],
				'icon'  => $mihanpress_options['contact_media_facebook_icon'],
				'title' => esc_html__( 'صفحه فیسبوک', 'mihanpress-addons' ),
			) : '',
			'1' === $mihanpress_options['contact_media_instagram'] ? array(
				'slug'  => 'instagram',
				'link'  => $mihanpress_options['contact_media_instagram_link'],
				'icon'  => $mihanpress_options['contact_media_instagram_icon'],
				'title' => esc_html__( 'صفحه اینستاگرام', 'mihanpress-addons' ),
			) : '',
			'1' === $mihanpress_options['contact_media_linkedin'] ? array(
				'slug'  => 'linkedin',
				'link'  => $mihanpress_options['contact_media_linkedin_link'],
				'icon'  => $mihanpress_options['contact_media_linkedin_icon'],
				'title' => esc_html__( 'صفحه لینکدین', 'mihanpress-addons' ),
			) : '',
			'1' === $mihanpress_options['contact_media_telegram'] ? array(
				'slug'  => 'telegram',
				'link'  => $mihanpress_options['contact_media_telegram_link'],
				'icon'  => 'flaticon-paper-plane',
				'title' => esc_html__( 'کانال تلگرام', 'mihanpress-addons' ),
			) : '',
			'1' === $mihanpress_options['contact_media_twitter'] ? array(
				'slug'  => 'twitter',
				'link'  => $mihanpress_options['contact_media_twitter_link'],
				'icon'  => 'flaticon-twitter-logo-silhouette',
				'title' => esc_html__( 'صفحه فیسبوک', 'mihanpress-addons' ),
			) : '',
			'1' === $mihanpress_options['contact_media_youtube'] ? array(
				'slug'  => 'youtube',
				'link'  => $mihanpress_options['contact_media_youtube_link'],
				'icon'  => 'flaticon-youtube',
				'title' => esc_html__( 'کانال یوتیوب', 'mihanpress-addons' ),
			) : '',
		);

		return $social_media_icons;
	}

	/**
	 * Register plugin action hooks and filters
	 *
	 * @since 1.0.0
	 */
	public function init() {
		/** Add Plugin files */
		$this->include_plugin_files();

		/** Load translation */
		add_action( 'init', array( $this, 'i18n' ) );

		/** Add widgets action */
		add_action( 'widgets_init', array( $this, 'register_widgets' ) );
	}
}

// Instantiate Plugin Class
global $mihanpress_addons;
$mihanpress_addons = new MihanPress_Addons();
$mihanpress_addons->instance();
