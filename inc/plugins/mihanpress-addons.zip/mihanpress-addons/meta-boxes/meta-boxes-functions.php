<?php

if ( file_exists( plugin_dir_path( __FILE__ ) . 'init.php' ) ) {
	require_once plugin_dir_path( __FILE__ ) . 'init.php';
}

define( 'MIHANPRESS_PREFIX', 'mihanpress_' );


function mihanpress_register_product_testimonial_meta_boxe() {
	$cmb = new_cmb2_box(
		array(
			'id'           => MIHANPRESS_PREFIX . 'product_testimonial',
			'title'        => esc_html__( 'نظرات مشتریان', 'mihanpress-addons' ),
			'object_types' => array( 'product' ),
			'priority'     => 'low',
		)
	);

	$group_field_id = $cmb->add_field(
		array(
			'id'          => MIHANPRESS_PREFIX . 'product_testimonial_items',
			'type'        => 'group',
			'description' => esc_html__( 'نظرات مشتریان خود را در این بخش وارد کنید.', 'mihanpress-addons' ),
			'options'     => array(
				'group_title'    => esc_html__( 'مشتری {#}', 'mihanpress-addons' ),
				'add_button'     => esc_html__( 'افزودن نظر', 'mihanpress-addons' ),
				'remove_button'  => esc_html__( 'حذف نظر', 'mihanpress-addons' ),
				'sortable'       => true,
				'closed'         => true,
				'remove_confirm' => esc_html__( 'آیا از حذف این نظر اطمینان دارید ؟', 'mihanpress-addons' ),
			),
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'نام مشتری', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'customer_name',
			'type' => 'text',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'کار مشتری', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'customer_job',
			'type' => 'text',
		)
	);
	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'آدرس مشتری', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'customer_link',
			'type' => 'text_url',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'متن نظر', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'customer_review',
			'type' => 'textarea_small',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'آواتار مشتری', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'image',
			'type' => 'file',
		)
	);
}
add_action( 'cmb2_admin_init', 'mihanpress_register_product_testimonial_meta_boxe' );

function mihanpress_register_product_updates_meta_boxe() {
	$cmb = new_cmb2_box(
		array(
			'id'           => MIHANPRESS_PREFIX . 'product_updates',
			'title'        => esc_html__( 'آپدیت های محصول', 'mihanpress-addons' ),
			'object_types' => array( 'product' ),
			'priority'     => 'low',
		)
	);
	$cmb->add_field(
		array(
			'desc'    => esc_html__( 'اگر محصول شما مجازی است میتوانید لیستی از آپدیت ها همراه با تغییرات آن ایجاد کنید.', 'cmb2' ),
			'id'      => MIHANPRESS_PREFIX . 'product_updates_content',
			'type'    => 'wysiwyg',
			'options' => array(
				'textarea_rows' => 10,
			),
		)
	);
}
add_action( 'cmb2_admin_init', 'mihanpress_register_product_updates_meta_boxe' );



function mihanpress_register_product_extra_button_meta_boxe() {
	$cmb = new_cmb2_box(
		array(
			'id'           => MIHANPRESS_PREFIX . 'product_buttons',
			'title'        => esc_html__( 'دکمه های زیر دکمه افزودن به سبد خرید', 'mihanpress-addons' ),
			'object_types' => array( 'product' ),
			'priority'     => 'low',
		)
	);

	$group_field_id = $cmb->add_field(
		array(
			'id'          => MIHANPRESS_PREFIX . 'product_button_items',
			'type'        => 'group',
			'description' => esc_html__( 'اگر میخواهید زیر دکمه سبد خرید دکمه های دیگری مانند "پیشنمایش آنلاین" ایجاد کنید از این بخش اقدام کنید.', 'mihanpress-addons' ),
			'options'     => array(
				'group_title'    => esc_html__( 'دکمه {#}', 'mihanpress-addons' ),
				'add_button'     => esc_html__( 'افزودن دکمه', 'mihanpress-addons' ),
				'remove_button'  => esc_html__( 'حذف دکمه', 'mihanpress-addons' ),
				'sortable'       => true,
				'closed'         => true,
				'remove_confirm' => esc_html__( 'آیا از حذف این دکمه اطمینان دارید ؟', 'mihanpress-addons' ),
			),
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'متن دکمه', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'button_text',
			'type' => 'text',
		)
	);
	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'لینک دکمه', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'button_link',
			'type' => 'text_url',
		)
	);
	$cmb->add_group_field(
		$group_field_id,
		array(
			'name'    => esc_html__( 'هدف دکمه', 'mihanpress-addons' ),
			'id'      => 'target',
			'type'    => 'select',
			'options' => array(
				'blank' => esc_html__( 'پنجره جدید', 'mihanpress-addons' ),
				'self'  => esc_html__( 'پنجره فعلی', 'mihanpress-addons' ),
			),
			'default' => 'blank',
		)
	);
	$cmb->add_group_field(
		$group_field_id,
		array(
			'name'    => esc_html__( 'رنگ دکمه', 'mihanpress-addons' ),
			'id'      => MIHANPRESS_PREFIX . 'button_color',
			'type'    => 'select',
			'options' => array(
				'btn-info'      => esc_html__( 'آبی', 'mihanpress-addons' ),
				'btn-success'   => esc_html__( 'سبز', 'mihanpress-addons' ),
				'btn-danger'    => esc_html__( 'قرمز', 'mihanpress-addons' ),
				'btn-secondary' => esc_html__( 'خاکستری', 'mihanpress-addons' ),
				'btn-dark'      => esc_html__( 'Dark', 'mihanpress-addons' ),
				'btn-light'     => esc_html__( 'Light', 'mihanpress-addons' ),
			),
			'default' => 'btn-info',
		)
	);
}
add_action( 'cmb2_admin_init', 'mihanpress_register_product_extra_button_meta_boxe' );



function mihanpress_register_product_extra_information_meta_boxe() {
	$cmb = new_cmb2_box(
		array(
			'id'           => MIHANPRESS_PREFIX . 'product_information',
			'title'        => esc_html__( 'اطلاعات اضافی محصول', 'mihanpress-addons' ),
			'object_types' => array( 'product' ),
			'priority'     => 'low',
		)
	);

	$group_field_id = $cmb->add_field(
		array(
			'id'          => MIHANPRESS_PREFIX . 'product_information_items',
			'type'        => 'group',
			'description' => esc_html__( 'از این بخش اطلاعات تکمیلی محصول خود را وارد کنید (مانند ورژن محصول)', 'mihanpress-addons' ),
			'options'     => array(
				'group_title'    => esc_html__( 'شماره {#}', 'mihanpress-addons' ),
				'add_button'     => esc_html__( 'افزودن', 'mihanpress-addons' ),
				'remove_button'  => esc_html__( 'حذف', 'mihanpress-addons' ),
				'sortable'       => true,
				'closed'         => true,
				'remove_confirm' => esc_html__( 'آیا از حذف این اطمینان دارید ؟', 'mihanpress-addons' ),
			),
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'متن', 'mihanpress-addons' ),
			'id'   => MIHANPRESS_PREFIX . 'information_text',
			'type' => 'text',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name'    => esc_html__( 'رنگ', 'mihanpress-addons' ),
			'id'      => MIHANPRESS_PREFIX . 'information_color',
			'type'    => 'select',
			'options' => array(
				'alert-info'    => esc_html__( 'آبی', 'mihanpress-addons' ),
				'alert-success' => esc_html__( 'سبز', 'mihanpress-addons' ),
				'alert-danger'  => esc_html__( 'قرمز', 'mihanpress-addons' ),
				'alert-warning' => esc_html__( 'نارنجی', 'mihanpress-addons' ),
			),
			'default' => 'alert-info',
		)
	);
}
add_action( 'cmb2_admin_init', 'mihanpress_register_product_extra_information_meta_boxe' );


function mihanpress_register_posts_extra_buttons() {
	$cmb = new_cmb2_box(
		array(
			'id'           => MIHANPRESS_PREFIX . 'post_extra_buttons',
			'title'        => esc_html__( 'لینک های سفارشی نوشته', 'mihanpress-addons' ),
			'object_types' => array( 'post' ),
			'priority'     => 'low',
		)
	);

	$group_field_id = $cmb->add_field(
		array(
			'id'          => MIHANPRESS_PREFIX . 'post_extra_buttons_items',
			'type'        => 'group',
			'description' => esc_html__( 'در این بخش لینک های اضافی برای نوشته مانند :‌دانلود فایل های آموزش ایجاد کنید. برای نمایش این دکمه ها باید از ابزارک مربوطه استفاده نمایید.', 'mihanpress-addons' ),
			'options'     => array(
				'group_title'    => esc_html__( 'شماره {#}', 'mihanpress-addons' ),
				'add_button'     => esc_html__( 'افزودن', 'mihanpress-addons' ),
				'remove_button'  => esc_html__( 'حذف', 'mihanpress-addons' ),
				'sortable'       => true,
				'closed'         => true,
				'remove_confirm' => esc_html__( 'آیا از حذف این اطمینان دارید ؟', 'mihanpress-addons' ),
			),
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'متن', 'mihanpress-addons' ),
			'id'   => 'text',
			'type' => 'text',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name' => esc_html__( 'لینک', 'mihanpress-addons' ),
			'id'   => 'link',
			'type' => 'text_url',
		)
	);
	$cmb->add_group_field(
		$group_field_id,
		array(
			'name'    => esc_html__( 'هدف دکمه', 'mihanpress-addons' ),
			'id'      => 'target',
			'type'    => 'select',
			'options' => array(
				'blank' => esc_html__( 'پنجره جدید', 'mihanpress-addons' ),
				'self'  => esc_html__( 'پنجره فعلی', 'mihanpress-addons' ),
			),
			'default' => 'blank',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name'    => esc_html__( 'نوع دکمه', 'mihanpress-addons' ),
			'id'      => 'type',
			'type'    => 'select',
			'options' => array(
				'download' => esc_html__( 'دانلود', 'mihanpress-addons' ),
				'normal'   => esc_html__( 'معمولی', 'mihanpress-addons' ),
			),
			'default' => 'normal',
		)
	);

	$cmb->add_group_field(
		$group_field_id,
		array(
			'name'    => esc_html__( 'رنگ', 'mihanpress-addons' ),
			'id'      => 'color',
			'type'    => 'select',
			'options' => array(
				'btn-info'      => esc_html__( 'آبی', 'mihanpress-addons' ),
				'btn-success'   => esc_html__( 'سبز', 'mihanpress-addons' ),
				'btn-danger'    => esc_html__( 'قرمز', 'mihanpress-addons' ),
				'btn-secondary' => esc_html__( 'خاکستری', 'mihanpress-addons' ),
				'btn-dark'      => esc_html__( 'Dark', 'mihanpress-addons' ),
				'btn-light'     => esc_html__( 'Light', 'mihanpress-addons' ),
			),
			'default' => 'alert-info',
		)
	);
}
add_action( 'cmb2_admin_init', 'mihanpress_register_posts_extra_buttons' );

function mihanpress_register_post_general_metaboxes() {
	$cmb = new_cmb2_box(
		array(
			'id'           => MIHANPRESS_PREFIX . 'post_general_settings',
			'title'        => esc_html__( 'تنظیمات عمومی', 'mihanpress-addons' ),
			'object_types' => array( 'post', 'page' ),
			'priority'     => 'low',
		)
	);
	$cmb->add_field(
		array(
			'name'             => esc_html__( 'نمایش سربرگ', 'mihanpress-addons' ),
			'id'               => MIHANPRESS_PREFIX . 'show_header',
			'type'             => 'select',
			'show_option_none' => true,
			'default'          => 'show',
			'options'          => array(
				'show' => esc_html__( 'فعال', 'mihanpress-addons' ),
				'hide' => esc_html__( 'غیر فعال', 'mihanpress-addons' ),
			),
		)
	);
	$cmb->add_field(
		array(
			'name'             => esc_html__( 'نمایش فوتر', 'mihanpress-addons' ),
			'id'               => MIHANPRESS_PREFIX . 'show_footer',
			'type'             => 'select',
			'show_option_none' => true,
			'default'          => 'show',
			'options'          => array(
				'show' => esc_html__( 'فعال', 'mihanpress-addons' ),
				'hide' => esc_html__( 'غیر فعال', 'mihanpress-addons' ),
			),
		)
	);
	$cmb->add_field(
		array(
			'name'             => esc_html__( 'نمایش مسیر راهنما', 'mihanpress-addons' ),
			'id'               => MIHANPRESS_PREFIX . 'show_breadcrumb',
			'type'             => 'select',
			'show_option_none' => true,
			'default'          => 'show',
			'options'          => array(
				'show' => esc_html__( 'فعال', 'mihanpress-addons' ),
				'hide' => esc_html__( 'غیر فعال', 'mihanpress-addons' ),
			),
		)
	);
}
add_action( 'cmb2_admin_init', 'mihanpress_register_post_general_metaboxes' );
