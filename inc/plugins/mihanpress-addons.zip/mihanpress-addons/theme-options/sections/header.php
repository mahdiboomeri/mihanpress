<?php
/**
 * Header Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title' => esc_html__( 'سربرگ', 'mihanpress-addons' ),
		'id'    => 'headerTab',
		'icon'  => 'el el-folder-close',
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'ساختار', 'mihanpress-addons' ),
		'id'         => 'header_layouts',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'     => 'header_elements',
				'type'   => 'section',
				'title'  => esc_html__( 'المان های سربرگ', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'sidenav_desktop',
				'type'    => 'switch',
				'title'   => esc_html__( 'منوی کشویی (دسکتاپ)', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'sidenav_desktop_position',
				'type'     => 'select',
				'title'    => esc_html__( 'مکان', 'mihanpress-addons' ),
				'options'  => array(
					'right' => esc_html__( 'راست', 'mihanpress-addons' ),
					'left'  => esc_html__( 'چپ', 'mihanpress-addons' ),
				),
				'default'  => 'left',
				'required' => array(
					array( 'sidenav_desktop', '=', true ),
				),
			),

			array(
				'id'      => 'searchform',
				'type'    => 'switch',
				'title'   => esc_html__( 'باکس جستجو', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'search_icon',
				'type'     => 'select',
				'title'    => esc_html__( 'آیکون', 'mihanpress-addons' ),
				'options'  => array(
					'flaticon-search-3' => esc_html__( 'پیشفرض', 'mihanpress-addons' ),
					'flaticon-search-2' => esc_html__( 'آیکون ۱', 'mihanpress-addons' ),
					'flaticon-search-1' => esc_html__( 'آیکون ۲', 'mihanpress-addons' ),
					'flaticon-loupe'    => esc_html__( 'آیکون ۳', 'mihanpress-addons' ),
					'flaticon-search-4' => esc_html__( 'آیکون ۴', 'mihanpress-addons' ),
				),
				'default'  => 'flaticon-search-3',
				'required' => array(
					array( 'searchform', '=', true ),
				),
			),
			array(
				'id'      => 'shopping_cart',
				'type'    => 'switch',
				'title'   => esc_html__( 'سبد خرید (ووکامرس)', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'shopping_cart_icon',
				'type'     => 'select',
				'title'    => esc_html__( 'آیکون', 'mihanpress-addons' ),
				'options'  => array(
					'flaticon-cart'            => esc_html__( 'پیشفرض', 'mihanpress-addons' ),
					'flaticon-ecommerce'       => esc_html__( 'آیکون ۱', 'mihanpress-addons' ),
					'flaticon-shopping-cart-4' => esc_html__( 'آیکون ۲', 'mihanpress-addons' ),
					'flaticon-shopping-cart-2' => esc_html__( 'آیکون ۳', 'mihanpress-addons' ),
					'flaticon-shopping-cart-1' => esc_html__( 'آیکون ۴', 'mihanpress-addons' ),
					'flaticon-shopping-cart'   => esc_html__( 'آیکون ۵', 'mihanpress-addons' ),
					'flaticon-shopping-cart-3' => esc_html__( 'آیکون ۶', 'mihanpress-addons' ),
					'flaticon-shopping-basket' => esc_html__( 'آیکون ۷', 'mihanpress-addons' ),
				),
				'default'  => 'flaticon-cart',
				'required' => array(
					array( 'shopping_cart', '=', true ),
				),
			),


			array(
				'id'      => 'nav_button',
				'type'    => 'switch',
				'title'   => esc_html__( 'دکمه', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'nav_button_type',
				'type'     => 'select',
				'title'    => esc_html__( 'نوع دکمه', 'mihanpress-addons' ),
				'options'  => array(
					'account' => esc_html__( 'لینک حساب کاربری', 'mihanpress-addons' ),
					'custom'  => esc_html__( 'لینک سفارشی', 'mihanpress-addons' ),
				),
				'default'  => 'account',
				'required' => array(
					array( 'nav_button', '=', true ),
				),
			),
			array(
				'id'       => 'nav_button_target',
				'type'     => 'select',
				'title'    => esc_html__( 'هدف دکمه', 'mihanpress-addons' ),
				'options'  => array(
					'blank' => esc_html__( 'پنجره جدید', 'mihanpress-addons' ),
					'self'  => esc_html__( 'پنجره فعلی', 'mihanpress-addons' ),
				),
				'default'  => 'blank',
				'required' => array(
					array( 'nav_button', '=', true ),
				),
			),
			array(
				'id'       => 'nav_button_account_logedin_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن دکمه پنل کاربری', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'در صورتی که کاربر از پیش وارد شده بود این دکمه به او نمایش داده میشود.', 'mihanpress-addons' ),
				'default'  => esc_html__( 'پنل کاربری', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'account' ),
				),
			),
			array(
				'id'       => 'nav_button_account_logedin_url',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک دکمه پنل کاربری', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'account' ),
				),
				'default'  => get_bloginfo( 'url' ) . '/panel',
			),
			array(
				'id'       => 'nav_button_account_login_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن دکمه ورود', 'mihanpress-addons' ),
				'default'  => esc_html__( 'ورود', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'account' ),
				),
			),
			array(
				'id'       => 'nav_button_account_login_url',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک دکمه ورود', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'account' ),
				),
				'default'  => wp_login_url(),
			),
			array(
				'id'       => 'nav_button_account_register_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن دکمه ثبت نام', 'mihanpress-addons' ),
				'default'  => esc_html__( 'ثبت نام', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'account' ),
				),
			),
			array(
				'id'       => 'nav_button_account_register_url',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک دکمه ثبت نام', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'account' ),
				),
				'default'  => wp_registration_url(),
			),


			array(
				'id'       => 'nav_button_custom_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن دکمه', 'mihanpress-addons' ),
				'default'  => esc_html__( 'لینک سفارشی', 'mihanpress-addons' ),
				'required' => array(
					array( 'nav_button_type', '=', 'custom' ),
				),
			),
			array(
				'id'       => 'nav_button_custom_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک دکمه', 'mihanpress-addons' ),
				'default'  => get_bloginfo( 'url' ),
				'required' => array(
					array( 'nav_button_type', '=', 'custom' ),
				),
				'default'  => get_bloginfo( 'url' ),
			),

		),
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'سربرگ چسبان', 'mihanpress-addons' ),
		'id'         => 'header_sticky',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'fix_header_type',
				'type'    => 'select',
				'title'   => esc_html__( 'رفتار سربرگ', 'mihanpress-addons' ),
				'options' => array(
					'static' => esc_html__( 'ثابت', 'mihanpress-addons' ),
					'fix'    => esc_html__( 'چسبان', 'mihanpress-addons' ),
				),
				'default' => 'static',
			),
			array(
				'id'       => 'fix_header_type_sticky',
				'type'     => 'switch',
				'title'    => esc_html__( 'چسبان بودن فقط هنگام اسکرول به بالا', 'mihanpress-addons' ),
				'default'  => true,
				'required' => array(
					array( 'fix_header_type', '=', 'fix' ),
				),
			),

			array(
				'id'            => 'fixed_header_top',
				'type'          => 'slider',
				'title'         => esc_html__( 'مکان فعال شدن سربرگ چسبان', 'mihanpress-addons' ),
				'subtitle'      => esc_html__( 'مقدار اسکرول صفحه از بالا برای فعال شدن سربرگ چسبان (واحد به پیکسل میباشد)', 'mihanpress-addons' ),
				'default'       => 450,
				'min'           => 1,
				'step'          => 1,
				'max'           => 1000,
				'display_value' => 'label',
				'required'      => array(
					array( 'fix_header_type', '=', 'fix' ),
				),
			),
		),
	)
);
