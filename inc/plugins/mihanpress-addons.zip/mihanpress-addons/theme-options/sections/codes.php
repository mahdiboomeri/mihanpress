<?php
/**
 * Custom Codes Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title'  => esc_html__( 'کد های سفارشی', 'mihanpress-addons' ),
		'id'     => 'codeTab',
		'icon'   => 'el el-css',
		'fields' => array(
			array(
				'id'       => 'site_custom_css',
				'type'     => 'ace_editor',
				'title'    => esc_html__( 'CSS سفارشی', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'استایل های دلخواه خود را اینجا وارد کنید.', 'mihanpress-addons' ),
				'mode'     => 'css',
				'theme'    => 'monokai',
			),
			array(
				'id'       => 'site_custom_js',
				'type'     => 'ace_editor',
				'title'    => esc_html__( 'Javascript سفارشی ', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'Javascript سفارشی خود را اینجا بنویسید', 'mihanpress-addons' ),
				'mode'     => 'javascript',
				'theme'    => 'chrome',
			),
		),
	)
);
