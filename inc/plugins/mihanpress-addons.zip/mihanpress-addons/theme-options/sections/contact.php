<?php
/**
 * Contact Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title'  => esc_html__( 'اطلاعات تماس', 'mihanpress-addons' ),
		'id'     => 'contactTab',
		'icon'   => 'el el-phone-alt',
		'fields' => array(
			array(
				'id'     => 'contact_real',
				'type'   => 'section',
				'title'  => esc_html__( 'حقیقی', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'contact_number',
				'type'    => 'text',
				'title'   => esc_html__( 'شماره تلفن', 'mihanpress-addons' ),
				'default' => '+989123456789',
			),
			array(
				'id'      => 'contact_email',
				'type'    => 'text',
				'title'   => esc_html__( 'ایمیل', 'mihanpress-addons' ),
				'default' => 'example@gmail.com',
			),
			array(
				'id'    => 'contact_address',
				'type'  => 'editor',
				'title' => esc_html__( 'آدرس', 'mihanpress-addons' ),
			),


			array(
				'id'     => 'contact_media',
				'type'   => 'section',
				'title'  => esc_html__( 'شبکه های اجتماعی', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			// Whatsapp
			array(
				'id'      => 'contact_media_whatsapp',
				'type'    => 'switch',
				'title'   => esc_html__( 'واتساپ', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'contact_media_whatsapp_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک واتساپ', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_whatsapp', '=', true ),
				),
			),
			// Facebook
			array(
				'id'      => 'contact_media_facebook',
				'type'    => 'switch',
				'title'   => esc_html__( 'فیسبوک', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'contact_media_facebook_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک فیسبوک', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_facebook', '=', true ),
				),
			),
			array(
				'id'       => 'contact_media_facebook_icon',
				'type'     => 'image_select',
				'title'    => esc_html__( 'انتخاب آیکون فیسبوک', 'mihanpress-addons' ),
				'options'  => array(
					'flaticon-facebook-1' => array(
						'alt' => esc_html__( 'آیکون ۱', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-facebook-1.png',
					),
					'flaticon-facebook'   => array(
						'alt' => esc_html__( 'آیکون ۲', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-facebook.png',
					),
				),
				'default'  => 'flaticon-facebook-1',
				'required' => array(
					array( 'contact_media_facebook', '=', true ),
				),
			),
			// Instagram
			array(
				'id'      => 'contact_media_instagram',
				'type'    => 'switch',
				'title'   => esc_html__( 'اینستاگرام', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'contact_media_instagram_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک اینستاگرام', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_instagram', '=', true ),
				),
			),
			array(
				'id'       => 'contact_media_instagram_icon',
				'type'     => 'image_select',
				'title'    => esc_html__( 'انتخاب آیکون اینستاگرام', 'mihanpress-addons' ),
				'options'  => array(
					'flaticon-instagram-1' => array(
						'alt' => esc_html__( 'آیکون ۱', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-instagram-1.png',
					),
					'flaticon-instagram'   => array(
						'alt' => esc_html__( 'آیکون ۲', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-instagram.png',
					),
				),
				'default'  => 'flaticon-instagram-1',
				'required' => array(
					array( 'contact_media_instagram', '=', true ),
				),
			),
			// Linkedin
			array(
				'id'      => 'contact_media_linkedin',
				'type'    => 'switch',
				'title'   => esc_html__( 'لینکدین', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'contact_media_linkedin_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک لینکدین', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_linkedin', '=', true ),
				),
			),
			array(
				'id'       => 'contact_media_linkedin_icon',
				'type'     => 'image_select',
				'title'    => esc_html__( 'انتخاب آیکون لینکدین', 'mihanpress-addons' ),
				'options'  => array(
					'flaticon-linkedin-1'    => array(
						'alt' => esc_html__( 'آیکون ۱', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-linkedin-1.png',
					),
					'flaticon-linkedin'      => array(
						'alt' => esc_html__( 'آیکون ۲', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-linkedin.png',
					),
					'flaticon-linkedin-logo' => array(
						'alt' => esc_html__( 'آیکون ۳', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/social-media/flaticon-linkedin-logo.png',
					),
				),
				'default'  => 'flaticon-linkedin-1',
				'required' => array(
					array( 'contact_media_linkedin', '=', true ),
				),
			),
			// Telegram
			array(
				'id'      => 'contact_media_telegram',
				'type'    => 'switch',
				'title'   => esc_html__( 'تلگرام', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'contact_media_telegram_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک تلگرام', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_telegram', '=', true ),
				),
			),
			// Twitter
			array(
				'id'      => 'contact_media_twitter',
				'type'    => 'switch',
				'title'   => esc_html__( 'تویتر', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'contact_media_twitter_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک تویتر', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_twitter', '=', true ),
				),
			),
			// Youtube
			array(
				'id'      => 'contact_media_youtube',
				'type'    => 'switch',
				'title'   => esc_html__( 'یوتیوب', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'contact_media_youtube_link',
				'type'     => 'text',
				'title'    => esc_html__( 'لینک یوتیوب', 'mihanpress-addons' ),
				'required' => array(
					array( 'contact_media_youtube', '=', true ),
				),
			),
		),
	)
);
