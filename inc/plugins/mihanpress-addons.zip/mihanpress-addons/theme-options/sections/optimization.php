<?php
/**
 * Optimization Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title'  => esc_html__( 'سئو و بهینه سازی', 'mihanpress-addons' ),
		'id'     => 'SEOTab',
		'icon'   => 'el el-tasks',
		'fields' => array(
			array(
				'id'       => 'string-query',
				'type'     => 'switch',
				'title'    => esc_html__( 'حذف کوئری استرینگ از منابع استاتیک', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'حذف شماره نسخه از فایل‌های استاتیک (مثلا style.css?ver=1.0) و کدگذاری آن داخل نام فایل (مثلا style.css). این کار می‌تواند امتیاز GTMetrix شما را افزایش دهد.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'wp-emoji',
				'type'     => 'switch',
				'title'    => esc_html__( 'غیر فعال کردن شکلک های پیشفرض وردپرس', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'با فعال کردن این گزینه اسکریپت های مربوط به شکلک های وردپرس حذف خواهند شد. این گزینه با کم کردن تعداد درخواست های HTTP سرعت وبسایت شما را افزایش میدهد.', 'mihanpress-addons' ),
				'default'  => true,
			),
		),

	)
);
