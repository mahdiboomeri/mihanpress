<?php
/**
 * General Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title' => esc_html__( 'تنظیمات عمومی', 'mihanpress-addons' ),
		'id'    => 'generalTab',
		'icon'  => 'el el-home',
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'تنظیمات پایه', 'mihanpress-addons' ),
		'id'         => 'basic_generalTab',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'site_keywords',
				'type'     => 'text',
				'title'    => esc_html__( 'کلمات کلیدی وبسایت', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'کلمات کلیدی وبسایت خود را در اینجا وارد کنید. برای جدا کردن آیتم ها از , استفاده کنید.', 'mihanpress-addons' ),
				'default'  => esc_html__( 'قالب وردپرس , قالب ایرانی , میهن پرس', 'mihanpress-addons' ),
			),
			array(
				'id'       => 'site_logo',
				'type'     => 'media',
				'url'      => true,
				'title'    => esc_html__( 'لوگوی وبسایت (دسکتاپ)', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'لوگوی وبسایت خود را آپلود کنید . این لوگو در سربرگ وبسایت و در دستگاه هایی با عرض بیشتر از ۹۹۲ پیکسل نمایش داده خواهد شد', 'mihanpress-addons' ),
				'default'  => array( 'url' => get_template_directory_uri() . '/assets/img/logo.png' ),
			),
			array(
				'id'       => 'site_logo_tablet',
				'type'     => 'media',
				'url'      => true,
				'title'    => esc_html__( 'لوگوی وبسایت (تبلت)', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'لوگوی وبسایت خود را آپلود کنید . این لوگو در سربرگ وبسایت و در دستگاه هایی با عرض بیشتر از ۷۰۰ پیکسل نمایش داده خواهد شد', 'mihanpress-addons' ),
				'default'  => array( 'url' => get_template_directory_uri() . '/assets/img/logo.png' ),
			),
			array(
				'id'       => 'site_logo_mobile',
				'type'     => 'media',
				'url'      => true,
				'title'    => esc_html__( 'لوگوی وبسایت (موبایل)', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'لوگوی وبسایت خود را آپلود کنید . این لوگو در سربرگ وبسایت و در دستگاه هایی با عرض کمتر از ۷۰۰ پیکسل نمایش داده خواهد شد', 'mihanpress-addons' ),
				'default'  => array( 'url' => get_template_directory_uri() . '/assets/img/logo.png' ),
			),
			array(
				'id'       => 'site_favicon',
				'type'     => 'media',
				'url'      => true,
				'title'    => esc_html__( 'نمادک وبسایت', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'فاوآیکون خود را ترجیحا با سایز ۳۲ *۳۲ پیکسل آپلود نمایید.', 'mihanpress-addons' ),
				'default'  => array( 'url' => get_template_directory_uri() . '/assets/img/favicon.png' ),
			),
			array(
				'id'       => 'sticky_sidebar',
				'type'     => 'switch',
				'title'    => esc_html__( 'سایدبار چسبان', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'با فعال کردن این گزینه در صفحاتی که سایدبار وجود دارد با اسکرول کردن کاربر سایدبار در کنار ثابت خواهد بود.', 'mihanpress-addons' ),
				'default'  => true,
			),

			array(
				'id'     => 'backtotop_section',
				'type'   => 'section',
				'title'  => esc_html__( 'دکمه بازگشت به بالا', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'backtotop',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش دکمه بازگشت به بالا', 'mihanpress-addons' ),
				'default' => true,
			),


			array(
				'id'       => 'backtotop_position',
				'type'     => 'select',
				'title'    => esc_html__( 'موقعیت دکمه', 'mihanpress-addons' ),
				'options'  => array(
					'left'  => esc_html__( 'چپ', 'mihanpress-addons' ),
					'right' => esc_html__( 'راست', 'mihanpress-addons' ),
				),
				'required' => array(
					array( 'backtotop', '=', true ),
				),
			),


			array(
				'id'     => 'box_radius_section',
				'type'   => 'section',
				'title'  => esc_html__( 'گوشه های مدور باکس ها', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'            => 'box_radius',
				'type'          => 'slider',
				'title'         => esc_html__( 'میزان گردی باکس ها', 'mihanpress-addons' ),
				'default'       => 20,
				'min'           => 10,
				'step'          => 10,
				'max'           => 20,
				'display_value' => 'label',
			),

		),
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'افکت بارگذاری', 'mihanpress-addons' ),
		'id'         => 'preloader_generalTab',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'       => 'preloader-on-off',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش افکت بارگذاری', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'فعال کردن افکت بارگذاری هنگام بارگذاری صفحه', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'preloaders',
				'type'     => 'select',
				'title'    => esc_html__( 'انتخاب افکت', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'افکت دلخواه خود را از بین موارد موجود انتخاب کنید.', 'mihanpress-addons' ),
				'options'  => array(
					'1' => esc_html__( 'افکت ۱', 'mihanpress-addons' ),
					'2' => esc_html__( 'افکت ۲', 'mihanpress-addons' ),
					'3' => esc_html__( 'افکت ۳', 'mihanpress-addons' ),
					'4' => esc_html__( 'افکت ۴', 'mihanpress-addons' ),
					'5' => esc_html__( 'افکت ۵', 'mihanpress-addons' ),
					'6' => esc_html__( 'افکت ۶', 'mihanpress-addons' ),
					'7' => esc_html__( 'افکت ۷', 'mihanpress-addons' ),

				),
				'default'  => '1',
				'required' => array(
					array( 'preloader-on-off', '=', true ),
				),
			),

		),
	)
);
