<?php
/**
 * Colors Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title' => esc_html__( 'رنگ بندی', 'mihanpress-addons' ),
		'id'    => 'ColorTab',
		'icon'  => 'el el-brush',
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'عمومی', 'mihanpress-addons' ),
		'id'         => 'ColorGeneralTab',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'     => 'general_color_heading',
				'type'   => 'section',
				'title'  => esc_html__( 'سفارشی سازی رنگ عمومی', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'body_background',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ پس زمینه وبسایت', 'mihanpress-addons' ),
				'default' => '#F5F5F7',
			),
			array(
				'id'      => 'general_color_switcher',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن سفارشی سازی بیشتر', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'general_color',
				'type'     => 'color_gradient',
				'title'    => esc_html__( 'رنگ عمومی', 'mihanpress-addons' ),
				'default'  => array(
					'from' => '#9667ea',
					'to'   => '#673ab7',
				),
				'required' => array(
					array( 'general_color_switcher', '=', true ),
				),
			),

			array(
				'id'       => 'general_color_shadow',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ سایه', 'mihanpress-addons' ),
				'default'  => '#c4aaf3',
				'required' => array(
					array( 'general_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'general_color_text_light',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن روشن', 'mihanpress-addons' ),
				'default'  => '#ffffff',
				'required' => array(
					array( 'general_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'general_color_text_dark',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن تاریک', 'mihanpress-addons' ),
				'default'  => '#35495c',
				'required' => array(
					array( 'general_color_switcher', '=', true ),
				),
			),

		),
	)
);


Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'دکمه ها', 'mihanpress-addons' ),
		'id'         => 'ColorButtonTab',
		'subsection' => true,
		'fields'     => array(
			// Button Primary
			array(
				'id'     => 'btn_primary_color_heading',
				'type'   => 'section',
				'title'  => esc_html__( 'سفارشی سازی رنگ دکمه Primary (.btn-primary)', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'btn_primary_color_switcher',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن سفارشی سازی', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'btn_primary_color',
				'type'     => 'color_gradient',
				'title'    => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default'  => array(
					'from' => '#9667ea',
					'to'   => '#673ab7',
				),
				'required' => array(
					array( 'btn_primary_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'btn_primary_color_text',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن', 'mihanpress-addons' ),
				'default'  => '#ffffff',
				'required' => array(
					array( 'btn_primary_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'btn_primary_color_shadow',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ سایه', 'mihanpress-addons' ),
				'default'  => '#c4aaf3',
				'required' => array(
					array( 'btn_primary_color_switcher', '=', true ),
				),
			),

			// Button Light
			array(
				'id'     => 'btn_light_color_heading',
				'type'   => 'section',
				'title'  => esc_html__( 'سفارشی سازی رنگ دکمه Light (.btn-light)', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'btn_light_color_switcher',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن سفارشی سازی', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'btn_light_color',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default'  => '#ebe5f7',
				'required' => array(
					array( 'btn_light_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'btn_light_color_text',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن', 'mihanpress-addons' ),
				'default'  => '#673ab7',
				'required' => array(
					array( 'btn_light_color_switcher', '=', true ),
				),
			),

		),
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'زیرمنو ها', 'mihanpress-addons' ),
		'id'         => 'ColorMenuTab',
		'subsection' => true,
		'fields'     => array(
			// Sub menu
			array(
				'id'     => 'sub_menu_color_heading',
				'type'   => 'section',
				'title'  => esc_html__( 'سفارشی سازی رنگ زیرمنو ها', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'sub_menu_color_switcher',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن سفارشی سازی', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'sub_menu_color',
				'type'     => 'color_gradient',
				'title'    => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default'  => array(
					'from' => '#4f2c8c',
					'to'   => '#5a7c9d',
				),
				'required' => array(
					array( 'sub_menu_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'sub_menu_color_text',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن', 'mihanpress-addons' ),
				'default'  => '#ffffff',
				'required' => array(
					array( 'sub_menu_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'sub_menu_color_text_hover',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن در صورت هاور', 'mihanpress-addons' ),
				'default'  => '#ffffff',
				'required' => array(
					array( 'sub_menu_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'sub_menu_color_shadow',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ سایه', 'mihanpress-addons' ),
				'default'  => '#51708d',
				'required' => array(
					array( 'sub_menu_color_switcher', '=', true ),
				),
			),

			// Collapsible menu
			array(
				'id'     => 'collapsible_color_heading',
				'type'   => 'section',
				'title'  => esc_html__( 'سفارشی سازی رنگ زیرمنو های نسخه موبایل', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'collapsible_color_switcher',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن سفارشی سازی', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'collapsible_color',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default'  => '#673ab7',
				'required' => array(
					array( 'collapsible_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'collapsible_color_text',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن', 'mihanpress-addons' ),
				'default'  => '#ffffff',
				'required' => array(
					array( 'collapsible_color_switcher', '=', true ),
				),
			),


			// Mega Menu
			array(
				'id'     => 'mega_menu_color_heading',
				'type'   => 'section',
				'title'  => esc_html__( 'سفارشی سازی رنگ مگامنو', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'mega_menu_color_switcher',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن سفارشی سازی', 'mihanpress-addons' ),
				'default' => false,
			),
			array(
				'id'       => 'mega_menu_color',
				'type'     => 'color_gradient',
				'title'    => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default'  => array(
					'from' => '#ffffff',
					'to'   => '#ffffff',
				),
				'required' => array(
					array( 'mega_menu_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'mega_menu_color_text',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن', 'mihanpress-addons' ),
				'default'  => '#35495c',
				'required' => array(
					array( 'mega_menu_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'mega_menu_color_text_hover',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ متن در صورت هاور', 'mihanpress-addons' ),
				'default'  => '#35495c',
				'required' => array(
					array( 'mega_menu_color_switcher', '=', true ),
				),
			),
			array(
				'id'       => 'mega_menu_color_shadow',
				'type'     => 'color',
				'title'    => esc_html__( 'رنگ سایه', 'mihanpress-addons' ),
				'default'  => '#E8E8E8',
				'required' => array(
					array( 'mega_menu_color_switcher', '=', true ),
				),
			),
		),
	)
);

