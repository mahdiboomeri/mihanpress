<?php
/**
 * Blog Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title' => esc_html__( 'وبلاگ', 'mihanpress-addons' ),
		'id'    => 'blogTab',
		'icon'  => 'el el-file-edit',
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'عمومی', 'mihanpress-addons' ),
		'id'         => 'blogTab_general',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'     => 'blog_archive_section',
				'type'   => 'section',
				'title'  => esc_html__( 'آرشیو مطالب وبلاک', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'blog_archive_template',
				'type'    => 'image_select',
				'title'   => esc_html__( 'قالب آرشیو وبلاگ', 'mihanpress-addons' ),
				'options' => array(
					'masonry'    => array(
						'alt' => esc_html__( 'masonry', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/layouts/masonry.png',
					),
					'block-card' => array(
						'alt' => esc_html__( 'block-card', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/layouts/block-card.png',
					),
					'row-card'   => array(
						'alt' => esc_html__( 'row-card', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/layouts/row-card.png',
					),
				),
				'default' => 'masonry',
			),

			array(
				'id'            => 'blog_single_posts_col',
				'type'          => 'slider',
				'title'         => esc_html__( 'اندازه ستون مطالب (single)', 'mihanpress-addons' ),
				'subtitle'      => esc_html__( 'اندازه بخش ستون محتوای مطلب را از ۱ تا ۱۲ انتخاب نمایید (توجه کنید که باید جمع ستون مطالب با سایدبار برابر ۱۲ شود)', 'mihanpress-addons' ),
				'default'       => 9,
				'min'           => 1,
				'step'          => 1,
				'max'           => 12,
				'display_value' => 'label',
			),
			array(
				'id'            => 'blog_single_sidebar_col',
				'type'          => 'slider',
				'title'         => esc_html__( 'اندازه ستون سایدبار مطلب (single)', 'mihanpress-addons' ),
				'subtitle'      => esc_html__( 'اندازه بخش سایدبار مطلب را از ۱ تا ۱۲ انتخاب نمایید (توجه کنید که باید جمع ستون مطالب با سایدبار برابر ۱۲ شود)', 'mihanpress-addons' ),
				'default'       => 3,
				'min'           => 1,
				'step'          => 1,
				'max'           => 12,
				'display_value' => 'label',
			),

			array(
				'id'     => 'blog_single_section',
				'type'   => 'section',
				'title'  => esc_html__( 'المان های ادامه مطلب', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'blog_single_template',
				'type'    => 'image_select',
				'title'   => esc_html__( 'قالب سربرگ ادامه مطلب', 'mihanpress-addons' ),
				'options' => array(
					'full-header'   => array(
						'alt' => esc_html__( 'full-header', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/layouts/single-full-header.png',
					),
					'normal-header' => array(
						'alt' => esc_html__( 'normal-header', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/layouts/single-normal-header.png',
					),

				),
				'default' => 'normal-header',
			),
			array(
				'id'       => 'hero_header_type',
				'type'     => 'select',
				'title'    => esc_html__( 'استایل', 'mihanpress-addons' ),
				'options'  => array(
					'skew' => esc_html__( 'Skew', 'mihanpress-addons' ),
					'wave' => esc_html__( 'Waves', 'mihanpress-addons' ),
				),
				'required' => array(
					array( 'blog_single_template', '=', 'full-header' ),
				),
				'default'  => 'skew',
			),
			array(
				'id'       => 'blog_single_thumbnail',
				'type'     => 'switch',
				'title'    => esc_html__( 'تصویر شاخص نوشته', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'نمایش تصویر شاخص نوشته در صفحه (single).', 'mihanpress-addons' ),
				'default'  => false,
			),
			array(
				'id'       => 'blog_single_tags',
				'type'     => 'switch',
				'title'    => esc_html__( 'برچسب ها', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'نمایش برچسب های مطلب را در صفحه ادامه مطلب مدیریت کنید.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'blog_single_update',
				'type'     => 'switch',
				'title'    => esc_html__( 'تاریخ بروزرسانی مطلب', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'آخرین تاریخ بروزرسانی مطلب نمایش داده خواهد شد.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'blog_single_date',
				'type'     => 'switch',
				'title'    => esc_html__( 'تاریخ ارسال مطلب', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'با فعال کردن این گزینه تاریخ ارسال مطلب نمایش داده خواهد شد.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'blog_single_date_type',
				'type'     => 'radio',
				'title'    => esc_html__( 'ساختار تاریخ', 'mihanpress-addons' ),
				'options'  => array(
					'human_time' => esc_html__( 'مدت زمان گذشته از ارسال نوشته : مثال (۳ روز پیش)', 'mihanpress-addons' ),
					'default'    => esc_html__( 'ساختار پیشفرض وردپرس : رجوع شود به (تنظیمات => عمومی => ساختار تاریخ)', 'mihanpress-addons' ),
				),
				'default'  => 'human_time',
				'required' => array(
					array( 'blog_single_date', '=', true ),
				),
			),

			array(
				'id'       => 'blog_single_like',
				'type'     => 'switch',
				'title'    => esc_html__( 'سیستم پیشرفته لایک Ajax', 'mihanpress-addons' ),
				'subtitle' => esc_html__( ' نمایش دکمه لایک مطالب در صفحه ادامه مطلب. توجه داشته باشید که غیرفعال کردن این گزینه ممکن است باعث از بین رفتن تعداد لایک های ذخیره شده در دیتابیس شود.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'blog_single_comment_count',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش تعداد نظرات مطلب', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'با فعال کردن این گزینه تعداد نظرات تایید شده نمایش خواهد داده شد.', 'mihanpress-addons' ),
				'default'  => true,
			),


			array(
				'id'      => 'blog_single_social_media',
				'type'    => 'switch',
				'title'   => esc_html__( 'آيکون های اشتراک گذاری در شبکه های اجتماعی', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'blog_single_social_media_icons',
				'type'     => 'checkbox',
				'title'    => esc_html__( 'مدیریت آیکون ها', 'mihanpress-addons' ),
				'options'  => array(
					'twitter'  => esc_html__( 'تویتر', 'mihanpress-addons' ),
					'whatsapp' => esc_html__( 'واتساپ', 'mihanpress-addons' ),
					'telegram' => esc_html__( 'تلگرام', 'mihanpress-addons' ),
					'linkedin' => esc_html__( 'لینکدین', 'mihanpress-addons' ),
				),
				'default'  => array(
					'twitter'  => '1',
					'whatsapp' => '1',
					'telegram' => '1',
					'linkedin' => '1',
				),
				'required' => array(
					array( 'blog_single_social_media', '=', true ),
				),
			),


			array(
				'id'       => 'blog_single_short_link',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش لینک کوتاه مطلب', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'لینک کوتاه مطلب در پایین محتوا قرار میگیرد و در صورتی که کاربر روی آن کلیک کند به صورت خودکار کپی خواهد شد.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'blog_single_author',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش باکس درباره نویسنده', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'اطلاعات نویسنده مانند آواتار و نام او در پایین مطلب نمایش داده خواهد شد.', 'mihanpress-addons' ),
				'default'  => true,
			),

			array(
				'id'     => 'blog_single_related_posts_section',
				'type'   => 'section',
				'title'  => esc_html__( 'مطالب مرتبط', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'blog_single_related_posts',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش مطالب مرتبط', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'blog_single_related_posts_logic',
				'type'     => 'select',
				'title'    => esc_html__( 'منطق نمایش مطالب مرتبط', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'شیوه انتخاب مطالب مرتبط را انتخاب کنید. برای مثال در صورت انتخاب گزینه دسته بندی ، مطالبی که دسته بندی مشابهی با مطلب جاری داشته باشند به عنوان مطلب مرتبط انتخاب خواهند شد.', 'mihanpress-addons' ),
				'options'  => array(
					'tags'     => esc_html__( 'بر اساس برچسب ها', 'mihanpress-addons' ),
					'category' => esc_html__( 'بر اساس دسته بندی ها', 'mihanpress-addons' ),
				),
				'default'  => 'category',
				'required' => array(
					array( 'blog_single_related_posts', '=', true ),
				),
			),
			array(
				'id'       => 'blog_single_related_posts_pre_page',
				'type'     => 'spinner',
				'title'    => esc_html__( 'تعداد مطالب مرتبط', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'تعداد مطالب مرتبطی را که قصد نمایش آنها را دارید را تعیین کنید . برای نمایش همه پست ها عدد -1 را وارد کنید.', 'mihanpress-addons' ),
				'default'  => 3,
				'min'      => -1,
				'step'     => 1,
				'max'      => 20,
				'required' => array(
					array( 'blog_single_related_posts', '=', true ),
				),
			),
		),
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'المان های پست آرشیو', 'mihanpress-addons' ),
		'id'         => 'blogTab_card_archive',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'card_archive_excerpt',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش خلاصه مطلب', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'      => 'card_archive_btn',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش دکمه ادامه مطلب', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'      => 'card_archive_metadata',
				'type'    => 'select',
				'title'   => esc_html__( 'متا دیتا', 'mihanpress-addons' ),
				'multi'   => true,
				'options' => array(
					'category' => esc_html__( 'دسته بندی', 'mihanpress-addons' ),
					'author'   => esc_html__( 'نویسنده', 'mihanpress-addons' ),
					'time'     => esc_html__( 'تاریخ انتشار', 'mihanpress-addons' ),
					'comments' => esc_html__( 'تعداد نظرات', 'mihanpress-addons' ),
				),
				'default' => array( 'category', 'author', 'time', 'comments' ),
			),
		),
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'المان های پست مطالب مرتبط', 'mihanpress-addons' ),
		'id'         => 'blogTab_card_relted',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'card_related_excerpt',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش خلاصه مطلب', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'      => 'card_related_btn',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش دکمه ادامه مطلب', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'      => 'card_related_metadata',
				'type'    => 'select',
				'title'   => esc_html__( 'متا دیتا', 'mihanpress-addons' ),
				'multi'   => true,
				'options' => array(
					'category' => esc_html__( 'دسته بندی', 'mihanpress-addons' ),
					'author'   => esc_html__( 'نویسنده', 'mihanpress-addons' ),
					'time'     => esc_html__( 'تاریخ انتشار', 'mihanpress-addons' ),
					'comments' => esc_html__( 'تعداد نظرات', 'mihanpress-addons' ),
				),
				'default' => array( 'category', 'author', 'time', 'comments' ),
			),
		),
	)
);
