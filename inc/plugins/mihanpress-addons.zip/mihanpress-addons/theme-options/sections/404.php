<?php
/**
 * 404 Page Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title'  => esc_html__( 'صفحه ۴۰۴', 'mihanpress-addons' ),
		'id'     => '404Tab',
		'icon'   => 'el el-remove',
		'fields' => array(
			array(
				'id'      => '404_background',
				'type'    => 'color_gradient',
				'title'   => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default' => array(
					'from' => '#70376F',
					'to'   => '#3E3062',
				),
			),
			array(
				'id'      => '404_content',
				'type'    => 'editor',
				'title'   => esc_html__( 'متن صفحه', 'mihanpress-addons' ),
				'default' => esc_html__( 'به نظر میرسه راه رو گم کردی. صفحه ای که دنبالش بودی اینجا نیست !', 'mihanpress-addons' ),
			),
			array(
				'id'      => '404_button_text',
				'type'    => 'text',
				'title'   => esc_html__( 'متن دکمه', 'mihanpress-addons' ),
				'default' => esc_html__( 'بازگشت به صفحه اصلی', 'mihanpress-addons' ),
			),
			array(
				'id'      => '404_button_link',
				'type'    => 'text',
				'title'   => esc_html__( 'لینک دکمه', 'mihanpress-addons' ),
				'default' => get_bloginfo( 'url' ),
			),
			array(
				'id'      => '404_button_color',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ دکمه', 'mihanpress-addons' ),
				'default' => '#FFCB39',
			),
			array(
				'id'      => '404_button_color_text',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ متن دکمه', 'mihanpress-addons' ),
				'default' => '#FFFFFF',
			),
			array(
				'id'      => '404_button_color_shadow',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ سایه دکمه', 'mihanpress-addons' ),
				'default' => '#ffde84',
			),
		),
	)
);
