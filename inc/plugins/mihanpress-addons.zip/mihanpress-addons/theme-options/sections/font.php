<?php
/**
 * Fonts Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title'  => esc_html__( 'فونت', 'mihanpress-addons' ),
		'id'     => 'fontTab',
		'icon'   => 'el el-fontsize',
		'fields' => array(
			array(
				'id'       => 'theme_fonts',
				'type'     => 'image_select',
				'title'    => esc_html__( 'انتخاب فونت', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'فونت دلخواه خود را از بین موارد موجود انتخاب کنید. اگر فونت مورد نظرتان میان در میان گزینه ها نبود ابتدا گزینه سفارشی را انتخاب کرده و سپس از بخش ظاهر شده اقدام به آپلود فونت خود نمایید.', 'mihanpress-addons' ),
				'options'  => array(
					'iransansweb'  => array(
						'alt' => esc_html__( 'فونت ایران سنس', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/iransansweb.png',
					),
					'iranyekanweb' => array(
						'alt' => esc_html__( 'فونت ایران یکان', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/iranyekanweb.png',
					),
					'yekan'        => array(
						'alt' => esc_html__( 'فونت یکان', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/yekan.png',
					),
					'vazir'        => array(
						'alt' => esc_html__( 'فونت وزیر', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/vazir.png',
					),
					'shabnam'      => array(
						'alt' => esc_html__( 'فونت شبنم', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/shabnam.png',
					),
					'samim'        => array(
						'alt' => esc_html__( 'فونت صمیم', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/samim.png',
					),
					'nahid'        => array(
						'alt' => esc_html__( 'فونت ناهید', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/nahid.png',
					),
					'sahel'        => array(
						'alt' => esc_html__( 'فونت ساحل', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/sahel.png',
					),
					'tanha'        => array(
						'alt' => esc_html__( 'فونت تنها', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/tanha.png',
					),
					'custom'       => array(
						'alt' => esc_html__( 'فونت سفارشی', 'mihanpress-addons' ),
						'img' => get_template_directory_uri() . '/assets/img/fonts/custom.png',
					),
				),
				'default'  => 'iransansweb',
			),
			array(
				'id'       => 'custom-font-woff2',
				'type'     => 'text',
				'title'    => esc_html__( 'فونت سفارشی', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'آدرس فونت با فرمت woff2', 'mihanpress-addons' ),
				'default'  => 'http://',
				'required' => array(
					array( 'theme_fonts', 'equals', 'custom' ),
				),
			),
			array(
				'id'       => 'custom-font-woff',
				'type'     => 'text',
				'title'    => '',
				'subtitle' => esc_html__( 'آدرس فونت با فرمت woff', 'mihanpress-addons' ),
				'default'  => 'http://',
				'required' => array(
					array( 'theme_fonts', 'equals', 'custom' ),
				),
			),
			array(
				'id'       => 'custom-font-ttf',
				'type'     => 'text',
				'title'    => '',
				'subtitle' => esc_html__( 'آدرس فونت با فرمت ttf', 'mihanpress-addons' ),
				'default'  => 'http://',
				'required' => array(
					array( 'theme_fonts', 'equals', 'custom' ),
				),
			),
			array(
				'id'       => 'custom-font-eot',
				'type'     => 'text',
				'title'    => '',
				'subtitle' => esc_html__( 'آدرس فونت با فرمت eot', 'mihanpress-addons' ),
				'default'  => 'http://',
				'required' => array(
					array( 'theme_fonts', 'equals', 'custom' ),
				),
			),

		),
	)
);

