<?php
/**
 * User Dashboard Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title' => esc_html__( 'پنل کاربری', 'mihanpress-addons' ),
		'id'    => 'userDashboardTab',
		'icon'  => 'el el-user',
	)
);


Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'داشبورد', 'mihanpress-addons' ),
		'id'         => 'user_dashboard_default_dashboard',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'wordpress_topbar',
				'type'    => 'switch',
				'title'   => esc_html__( 'غیر فعال کردن نوار سیاه وردپرس برای کاربرای عادی', 'mihanpress-addons' ),
				'default' => true,
			),

			// Registred days box
			array(
				'id'     => 'registred_days_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس تعداد روز های عضویت', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'registred_days',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش باکس تعداد روز های عضویت', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'registred_days_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن باکس تعداد روز های عضویت', 'mihanpress-addons' ),
				'default'  => esc_html__( 'روز عضویت', 'mihanpress-addons' ),
				'required' => array(
					array( 'registred_days', '=', true ),
				),
			),


			// wallet box
			array(
				'id'     => 'woo_wallet_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس موجودی کیف پول', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'woo_wallet',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش موجودی کیف پول', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'woo_wallet_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن باکس موجودی کیف پول', 'mihanpress-addons' ),
				'default'  => esc_html__( 'موجودی کیف پول', 'mihanpress-addons' ),
				'required' => array(
					array( 'woo_wallet', '=', true ),
				),
			),


			// Approved comments box
			array(
				'id'     => 'approved_comments_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس تعداد نظرات', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'approved_comments',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش تعداد نظرات تایید شده', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'approved_comments_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن باکس تعداد نظرات', 'mihanpress-addons' ),
				'default'  => esc_html__( 'نظر تایید شده', 'mihanpress-addons' ),
				'required' => array(
					array( 'approved_comments', '=', true ),
				),
			),


			// Woocommerce completed orders box
			array(
				'id'     => 'completed_orders_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس تعداد سفارشات', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'completed_orders',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش سفارش های تکمیل شده (ووکامرس)', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'completed_orders_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن باکس تعداد سفارشات', 'mihanpress-addons' ),
				'default'  => esc_html__( 'سفارش تکمیل شده', 'mihanpress-addons' ),
				'required' => array(
					array( 'completed_orders', '=', true ),
				),
			),



			// Woocommerce total purchased amount
			array(
				'id'     => 'total_purchased_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس مبلغ سفارشات', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'total_purchased',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش جمع مبلغ سفارش ها (ووکامرس)', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'total_purchased_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن باکس مبلغ سفارشات', 'mihanpress-addons' ),
				'default'  => esc_html__( 'هزار تومان مجموع خرید', 'mihanpress-addons' ),
				'required' => array(
					array( 'total_purchased', '=', true ),
				),
			),



			// Purchased files count section
			array(
				'id'     => 'purchased_files_count_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس تعداد فایل های خریداری شده', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'purchased_files_count',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش تعداد فایل های خریداری شده (EDD)', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'purchased_files_count_text',
				'type'     => 'text',
				'title'    => esc_html__( 'متن باکس تعداد فایل های خرداری شده', 'mihanpress-addons' ),
				'default'  => esc_html__( 'فایل خریداری شده', 'mihanpress-addons' ),
				'required' => array(
					array( 'purchased_files_count', '=', true ),
				),
			),


			// Coupon section
			array(
				'id'     => 'coupon_section',
				'type'   => 'section',
				'title'  => esc_html__( 'باکس کد تخفیف', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'coupon',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش کد تخفیف در سبد خرید', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'coupon_itself',
				'type'     => 'text',
				'title'    => esc_html__( 'کد تخفیف', 'mihanpress-addons' ),
				'default'  => '20OFF',
				'required' => array(
					array( 'coupon', '=', true ),
				),
			),
			array(
				'id'       => 'coupon_description',
				'type'     => 'text',
				'title'    => esc_html__( 'توضیحات کد تخفیف', 'mihanpress-addons' ),
				'default'  => esc_html__( 'کد تخفیف ۲۰ درصدی برای شما', 'mihanpress-addons' ),
				'required' => array(
					array( 'coupon', '=', true ),
				),
			),
		),
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'مدیریت منوها', 'mihanpress-addons' ),
		'id'         => 'user_dashboard_menus',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'    => 'mihanpress_dashboard_shortcodes',
				'type'  => 'info',
				'style' => 'success',
				'title' => esc_html__( 'لیستی از کدکوتاه های پر استفاده', 'mihanpress-addons' ),
				'desc'  => wp_kses_post( __( '<br><strong>ووکامرس</strong><ul><li>لیست سفارش های کاربر  :  [mihanpress_woo_orders]</li><li>لیست دانلود های کاربر :  [mihanpress_woo_downloads]</li><li>آدرس های کاربر : [mihanpress_woo_address]</li><li>لیست محصولات پسندیده شده (مربوط به افزونه yith wishlist) : [yith_wcwl_wishlist]</li></ul><strong>افزونه EDD</strong><ul><li>ویرایش حساب کاربری : [edd_profile_editor]</li><li>لیست محصولات خریداری شده توسط کاربر‌ : [purchase_history]</li><li>لیست دانلود های کاربر : [download_history]</li><li>محصولات پسندیده شده کاربر (مربوط به افزونه EDD wishlists) : [edd_wish_lists]</li></ul><strong>مربوط به قالب</strong><ul><li>لیست نوشته های پسندیده شده : [mihanpress_user_likes]</li></ul>', 'mihanpress-addons' ) ),
			),
			array(
				'id'          => 'mihanpress_dashboard_menus',
				'type'        => 'slides',
				'title'       => '',
				'subtitle'    => esc_html__( 'منو های پنل کاربران خود را از این بخش مدیریت کنید.میتوانید با کشیدن و رها کردن آیتم ها تریتیب آنها را مدیریت کنید.', 'mihanpress-addons' ),
				'desc'        => esc_html__( 'توجه داشته باشید که باید از بین فیلد های کد کوتاه و لینک فقط یکی را پر کنید.', 'mihanpress-addons' ),
				'placeholder' => array(
					'title'       => esc_html__( 'نام منو', 'mihanpress-addons' ),
					'description' => esc_html__( 'کد کوتاه منو', 'mihanpress-addons' ),
					'url'         => esc_html__( 'لینک منو', 'mihanpress-addons' ),
				),
			),

		),
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'اطلاعیه ها', 'mihanpress-addons' ),
		'id'         => 'user_dashboard_alerts',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'    => 'user_dashboard_alert_1',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۱', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_2',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۲', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_3',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۳', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_4',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۴', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_5',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۵', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_6',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۶', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_7',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۷', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_8',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۸', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_9',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۹', 'mihanpress-addons' ),
			),
			array(
				'id'    => 'user_dashboard_alert_10',
				'type'  => 'editor',
				'title' => esc_html__( 'اطلاعیه ۱۰', 'mihanpress-addons' ),
			),
		),
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'صفحه ورود', 'mihanpress-addons' ),
		'id'         => 'user_dashboard_login',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'    => 'login_hint',
				'type'  => 'info',
				'style' => 'success',
				'title' => esc_html__( 'راهنمای تغییر آدرس صفحه ورود', 'mihanpress-addons' ),
				'desc'  => esc_html__( 'برای تغییر آدرس صفحه ورود به بخش تنظیمات -> پیوند های یکتا وبسایت خود مراجعه کنید و از بخش "تغییر آدرس صفحه ورود - قالب میهن پرس" اقدام به تغییر آدرس نمایید', 'mihanpress-addons' ),
			),
			array(
				'id'       => 'panel_slug',
				'type'     => 'text',
				'title'    => esc_html__( 'نامک برگه پنل کاربران', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'برای نمایش پنل کاربران ابتدا به قسمت برگه ها رفته و یک برگه ایجاد کنید سپس شورتکد [mihanpress_user_dashboard] را در برگه موردنظر قرار دهید. بعد از ذخیره برگه لطفا نامک آن را در کادر مقابل بنویسید. <br> برای مثال اگر آدرس برگه برابر site.ir/panel بود نامک برگه panel خواهد بود.', 'mihanpress-addons' ),
			),
			array(
				'id'       => 'login_bg',
				'type'     => 'media',
				'url'      => true,
				'title'    => esc_html__( 'تصویر پس زمینه', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'تصویر پس زمینه صفحه لاگین را آپلود نمایید.', 'mihanpress-addons' ),
				'default'  => array( 'url' => get_template_directory_uri() . '/assets/img/login-bg.jpg' ),
			),
			array(
				'id'       => 'login_logo',
				'type'     => 'media',
				'url'      => true,
				'title'    => esc_html__( 'لوگوی صفحه ورود', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'لوگوی نمایش داده شده صفحه ورود را آپلود کنید (اگر میخواهید لوگوی پیشفرض وردپرس نمایش داده شود این فیلد را خالی بگذارید)', 'mihanpress-addons' ),
			),
			array(
				'id'            => 'login_logo_width',
				'type'          => 'slider',
				'title'         => esc_html__( 'طول لوگوی موردنظر خود را وارد کنید (واحد به پیکسل میباشد)', 'mihanpress-addons' ),
				'default'       => 80,
				'min'           => 1,
				'step'          => 1,
				'max'           => 300,
				'display_value' => 'label',
			),
			array(
				'id'            => 'login_logo_height',
				'type'          => 'slider',
				'title'         => esc_html__( 'عرض لوگوی موردنظر خود را وارد کنید (واحد به پیکسل میباشد)', 'mihanpress-addons' ),
				'default'       => 80,
				'min'           => 1,
				'step'          => 1,
				'max'           => 300,
				'display_value' => 'label',
			),
		),
	)
);


$error_codes = array(
	array(
		'id'    => 'test_cookie',
		'label' => esc_html__( 'غیرفعال بودن کوکی‌ها', 'mihanpress-addons' ),
	),
	array(
		'id'    => 'invalid_username',
		'label' => esc_html__( 'نام‌کاربری اشتباه', 'mihanpress-addons' ),
	),
	array(
		'id'    => 'incorrect_password',
		'label' => esc_html__( 'رمزعبور اشتباه', 'mihanpress-addons' ),
	),
	array(
		'id'    => 'empty_username',
		'label' => esc_html__( 'نام‌کاربری خالی', 'mihanpress-addons' ),
	),
	array(
		'id'    => 'empty_password',
		'label' => esc_html__( 'رمزعبور خالی', 'mihanpress-addons' ),
	),
);

$fields = array();

$fields[] = array(
	'id'    => 'login_messagesـ_hint',
	'type'  => 'info',
	'style' => 'success',
	'desc'  => esc_html__( 'در این قسمت می‌توانید متن خطاهایی را که کاربر می‌تواند در صفحه ورود دریافت کند را مدیریت کنید.', 'mihanpress-addons' ),
);

foreach ( (array) $error_codes as $code ) {
	$fields[] = array(
		'id'     => 'login_' . $code['id'] . '_heading',
		'type'   => 'section',
		/* Translators: %s name of error */
		'title'  => sprintf( esc_html__( 'خطای %s', 'mihanpress-addons' ), $code['label'] ),
		'indent' => true,
	);
	$fields[] = array(
		'id'      => 'login_' . $code['id'],
		'type'    => 'switch',
		'title'   => esc_html__( 'ویرایش متن خطا', 'mihanpress-addons' ),
		'default' => false,
	);
	$fields[] = array(
		'id'       => 'login_' . $code['id'] . '_text',
		'type'     => 'editor',
		'title'    => esc_html__( 'متن خطا', 'mihanpress-addons' ),
		'required' => array(
			array( 'login_' . $code['id'], '=', true ),
		),
	);
}

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'خطاهای ورود', 'mihanpress-addons' ),
		'id'         => 'login_errorsTab',
		'subsection' => true,
		'fields'     => $fields,
	)
);
