<?php
/**
 * Footer Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title' => esc_html__( 'فوتر', 'mihanpress-addons' ),
		'id'    => 'footerTab',
		'icon'  => 'el el-list',
	)
);

Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'تنظیمات لایه بندی فوتر', 'mihanpress-addons' ),
		'id'         => 'footer_general',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'            => 'footer_widget_counts',
				'type'          => 'slider',
				'title'         => esc_html__( 'تعداد جایگاه های ابزارک', 'mihanpress-addons' ),
				'subtitle'      => esc_html__( 'تعداد جایگاه های ابزارک فوتر را تعیین کنید. برای استفاده از این جایگاه ها به بخش نمایش => ابزارک ها مراجعه کنید.', 'mihanpress-addons' ),
				'default'       => 4,
				'min'           => 1,
				'step'          => 1,
				'max'           => 8,
				'display_value' => 'label',
			),
			array(
				'id'       => 'footer_columns',
				'type'     => 'select',
				'title'    => esc_html__( 'تعداد ستون های فوتر', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'تعداد ستون های فوتر را تعیین کنید.', 'mihanpress-addons' ),
				'options'  => array(
					'1' => esc_html__( 'یک ستون', 'mihanpress-addons' ),
					'2' => esc_html__( 'دو ستون', 'mihanpress-addons' ),
					'3' => esc_html__( 'سه ستون', 'mihanpress-addons' ),
					'4' => esc_html__( 'چهار ستون', 'mihanpress-addons' ),
					'6' => esc_html__( 'شش ستون', 'mihanpress-addons' ),
				),
				'default'  => '3',
			),
			array(
				'id'       => 'footer_columns_tablet',
				'type'     => 'select',
				'title'    => esc_html__( 'تعداد ستون های فوتر در حالت تبلت', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'تعداد ستون های فوتر را در حالت تبلت تعیین کنید.', 'mihanpress-addons' ),
				'options'  => array(
					'1' => esc_html__( 'یک ستون', 'mihanpress-addons' ),
					'2' => esc_html__( 'دو ستون', 'mihanpress-addons' ),
					'3' => esc_html__( 'سه ستون', 'mihanpress-addons' ),
					'4' => esc_html__( 'چهار ستون', 'mihanpress-addons' ),
					'6' => esc_html__( 'شش ستون', 'mihanpress-addons' ),
				),
				'default'  => '1',

			),
			array(
				'id'       => 'footer_widget_title_size',
				'type'     => 'spinner',
				'title'    => esc_html__( 'اندازه متن تگ های عنوان', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'اندازه عناوین ابزارک ها را به پیکسل تعیین کنید.', 'mihanpress-addons' ),
				'default'  => '20',
				'min'      => '6',
				'step'     => '1',
				'max'      => '100',
			),
			array(
				'id'       => 'footer_menu',
				'type'     => 'select',
				'data'     => 'menus',
				'title'    => esc_html__( 'فهرست فوتر', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'فهرستی که قصد دارید در فوتر نمایش داده شود را از قسمت نمایش =>فهرست ها ایجاد نمایید و از این قسمت انتخاب نمایید', 'mihanpress-addons' ),
			),
			array(
				'id'      => 'footer_copyright',
				'type'    => 'editor',
				'title'   => esc_html__( 'متن کپی رایت', 'mihanpress-addons' ),
				'default' => 'کدنویسی شده توسط <a href="https://www.zhaket.com/store/web/thunder-wp/">تندر وردپرس</a>.',
			),
			array(
				'id'     => 'footer_color',
				'type'   => 'section',
				'title'  => esc_html__( 'رنگ بندی', 'mihanpress-addons' ),
				'indent' => true, // Indent all options below until the next 'section' option is set.
			),
			array(
				'id'      => 'footer_border_color',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ حاشیه بالای فوتر', 'mihanpress-addons' ),
				'default' => '#673ab7',
			),
			array(
				'id'      => 'footer_color_main_bg',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ پس زمینه', 'mihanpress-addons' ),
				'default' => '#eceff1',
			),
			array(
				'id'      => 'footer_color_copyright_bg',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ پس زمینه کپی رایت', 'mihanpress-addons' ),
				'default' => '#d7dee0',
			),
			array(
				'id'      => 'footer_color_topbar_bg',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ پس زمینه باکس بالای ابزارک ها', 'mihanpress-addons' ),
				'default' => '#eceff1',
			),
			array(
				'id'      => 'footer_color_topbar_text',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ متن های باکس بالای ابزارک ها', 'mihanpress-addons' ),
				'default' => '#4a5f73',
			),
			array(
				'id'      => 'footer_color_main_heading_text',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ متن های عنوان', 'mihanpress-addons' ),
				'default' => '#4a5f73',
			),
			array(
				'id'      => 'footer_color_main_text',
				'type'    => 'color',
				'title'   => esc_html__( 'رنگ متن های محتوا', 'mihanpress-addons' ),
				'default' => '#4a5f73',
			),

		),
	)
);
Redux::set_section(
	$opt_name,
	array(
		'title'      => esc_html__( 'باکس بالای فوتر', 'mihanpress-addons' ),
		'id'         => 'footer_topbar',
		'subsection' => true,
		'fields'     => array(
			array(
				'id'      => 'footer_topbar_switch',
				'type'    => 'switch',
				'title'   => esc_html__( 'فعال کردن باکس بالای فوتر', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'       => 'footer_topbar_type',
				'type'     => 'select',
				'title'    => esc_html__( 'نوع باکس', 'mihanpress-addons' ),
				'options'  => array(
					'text'  => esc_html__( 'متن', 'mihanpress-addons' ),
					'badge' => esc_html__( 'Badge', 'mihanpress-addons' ),
					'menu'  => esc_html__( 'فهرست', 'mihanpress-addons' ),
				),
				'default'  => 'text',
				'required' => array(
					array( 'footer_topbar_switch', '=', true ),
				),
			),
			array(
				'id'       => 'footer_topbar_text_content',
				'type'     => 'editor',
				'title'    => esc_html__( 'محتوای باکس', 'mihanpress-addons' ),
				'required' => array(
					array( 'footer_topbar_type', '=', 'text' ),
				),
			),
			array(
				'id'          => 'footer_topbar_badge_content',
				'type'        => 'slides',
				'title'       => esc_html__( 'محتوای باکس', 'mihanpress-addons' ),
				'placeholder' => array(
					'title'       => esc_html__( 'عنوان', 'mihanpress-addons' ),
					'description' => esc_html__( 'توضیحات', 'mihanpress-addons' ),
					'url'         => esc_html__( 'لینک', 'mihanpress-addons' ),
				),
				'required'    => array(
					array( 'footer_topbar_type', '=', 'badge' ),
				),
			),
			array(
				'id'       => 'footer_topbar_menu_content',
				'type'     => 'select',
				'data'     => 'menus',
				'title'    => esc_html__( 'انتخاب فهرست', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'فهرستی که قصد دارید در فوتر نمایش داده شود را از قسمت نمایش =>فهرست ها ایجاد نمایید و از این قسمت انتخاب نمایید', 'mihanpress-addons' ),
				'required' => array(
					array( 'footer_topbar_type', '=', 'menu' ),
				),
			),

		),
	)
);
