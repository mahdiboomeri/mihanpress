<?php
/**
 * WooCommerce Tab
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Redux::set_section(
	$opt_name,
	array(
		'title'  => esc_html__( 'فروشگاه (ووکامرس)', 'mihanpress-addons' ),
		'id'     => 'woocommerceTab',
		'icon'   => 'el el-shopping-cart',
		'fields' => array(
			array(
				'id'       => 'shop_products_per_page',
				'type'     => 'spinner',
				'title'    => esc_html__( 'تعداد محصولات در هر صفحه از فروشگاه', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'تعداد محصولاتی را که قصد نمایش آنها را دارید را تعیین کنید . برای نمایش همه محصولات عدد -1 را وارد کنید.', 'mihanpress-addons' ),
				'default'  => '20',
				'min'      => '-1',
				'step'     => '1',
				'max'      => '100',
			),
			array(
				'id'            => 'shop_content_col',
				'type'          => 'slider',
				'title'         => esc_html__( 'اندازه ستون محتوای محصولات', 'mihanpress-addons' ),
				'subtitle'      => esc_html__( 'اندازه بخش ستون محتوای محصولات را از ۱ تا ۱۲ انتخاب نمایید (توجه کنید که باید جمع ستون محتوا با سایدبار برابر ۱۲ شود)', 'mihanpress-addons' ),
				'default'       => 9,
				'min'           => 1,
				'step'          => 1,
				'max'           => 12,
				'display_value' => 'label',
			),
			array(
				'id'            => 'shop_sidebar_col',
				'type'          => 'slider',
				'title'         => esc_html__( 'اندازه ستون سایدبار محصولات', 'mihanpress-addons' ),
				'subtitle'      => esc_html__( 'اندازه بخش سایدبار محصولات را از ۱ تا ۱۲ انتخاب نمایید (توجه کنید که باید جمع ستون محتوا با سایدبار برابر ۱۲ شود)', 'mihanpress-addons' ),
				'default'       => 3,
				'min'           => 1,
				'step'          => 1,
				'max'           => 12,
				'display_value' => 'label',
			),

			array(
				'id'       => 'shop_dokan_vendor_info',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش اطلاعات فروشنده در صفحه محصولات', 'mihanpress-addons' ),
				'subtitle' => esc_html__( 'این گزینه مربوط به افزونه دکان میباشد و با استفاده از آن میتوانید نمایش اطلاعات فروشنده را در صفحه محصولات مدیریت کنید.', 'mihanpress-addons' ),
				'default'  => true,
			),
			array(
				'id'       => 'shop_category_tag',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش تگ و دسته بندی محصول', 'mihanpress-addons' ),
				'subtitle' => esc_html__( ' با غیر فعال کردن این گزینه میتوانید تگ و دسته بندی محصول را از دید کاربر پنهان کنید.', 'mihanpress-addons' ),
				'default'  => false,
			),
			array(
				'id'       => 'shop_single_product_gallery',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش تصویر و گالری محصول', 'mihanpress-addons' ),
				'subtitle' => esc_html__( ' این گزینه نمایش تصویر و گالری محصول را در صفحه معرفی محصول (single) تعیین میکند.', 'mihanpress-addons' ),
				'default'  => false,
			),
			array(
				'id'       => 'shop_user_reply',
				'type'     => 'switch',
				'title'    => esc_html__( 'نمایش دکمه پاسخ دادن به نظرات', 'mihanpress-addons' ),
				'subtitle' => esc_html__( ' با استفاده این گزینه میتوانید به کاربران عادی وبسایت اجازه پاسخ دادن به نظرات دیگر کاربران را بدهید.', 'mihanpress-addons' ),
				'default'  => true,
			),


			array(
				'id'      => 'shop_update_date',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش آخرین تاریخ بروزرسانی محصول', 'mihanpress-addons' ),
				'default' => true,
			),
			array(
				'id'      => 'shop_related_products',
				'type'    => 'switch',
				'title'   => esc_html__( 'نمایش محصولات مرتبط', 'mihanpress-addons' ),
				'default' => true,
			),

		),
	)
);
