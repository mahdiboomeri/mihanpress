<?php
/**
 * Theme options config
 *
 * @package MihanPress Addons
 * @since 1.0.0
 */

if ( ! class_exists( 'Redux' ) ) {
	return;
}

/**
 * Load scripts without CDN
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'ReduxFramework_extension_vendor_support' ) && file_exists( plugin_dir_path( __FILE__ ) . 'extensions/vendor_support/extension_vendor_support.php' ) ) {
	require_once plugin_dir_path( __FILE__ ) . 'extensions/vendor_support/extension_vendor_support.php';
	new ReduxFramework_extension_vendor_support();
}


$opt_name = 'mihanpress_options';

$theme = wp_get_theme();

$args = array(
	'opt_name'             => $opt_name,
	'display_name'         => esc_html__( 'تنظیمات قالب میهن پرس', 'mihanpress-addons' ),
	/* Translators: %s current theme version. */
	'display_version'      => sprintf( esc_html__( 'نسخه: %s', 'mihanpress-addons' ), $theme->get( 'Version' ) ),
	'menu_type'            => 'menu',
	'allow_sub_menu'       => true,
	'menu_title'           => esc_html__( 'تنظیمات میهن پرس', 'mihanpress-addons' ),
	'page_title'           => esc_html__( 'تنظیمات میهن پرس', 'mihanpress-addons' ),
	'google_api_key'       => '',
	'google_update_weekly' => false,
	'async_typography'     => true,
	'admin_bar'            => true,
	'admin_bar_icon'       => '',
	'admin_bar_priority'   => 50,
	'global_variable'      => $opt_name,
	'dev_mode'             => false,
	'update_notice'        => false,
	'customizer'           => true,
	'page_priority'        => null,
	'page_parent'          => 'themes.php',
	'page_permissions'     => 'manage_options',
	'menu_icon'            => '',
	'last_tab'             => '',
	'page_icon'            => 'icon-themes',
	'page_slug'            => 'themeoptions',
	'save_defaults'        => true,
	'default_show'         => false,
	'default_mark'         => '',
	'show_import_export'   => true,
	'footer_credit'        => ' ',
	'use_cdn'              => false,
);

Redux::setArgs( $opt_name, $args );


require_once Redux_Core::$dir . '../sections/general.php';
require_once Redux_Core::$dir . '../sections/font.php';
require_once Redux_Core::$dir . '../sections/colors.php';
require_once Redux_Core::$dir . '../sections/header.php';
require_once Redux_Core::$dir . '../sections/footer.php';
require_once Redux_Core::$dir . '../sections/contact.php';
require_once Redux_Core::$dir . '../sections/blog.php';
require_once Redux_Core::$dir . '../sections/woocommerce.php';
require_once Redux_Core::$dir . '../sections/dashboard.php';
require_once Redux_Core::$dir . '../sections/404.php';
require_once Redux_Core::$dir . '../sections/codes.php';
require_once Redux_Core::$dir . '../sections/optimization.php';
